package io.axoniq.axonserver.grpc.admin;

import static io.grpc.MethodDescriptor.generateFullMethodName;
import static io.grpc.stub.ClientCalls.asyncBidiStreamingCall;
import static io.grpc.stub.ClientCalls.asyncClientStreamingCall;
import static io.grpc.stub.ClientCalls.asyncServerStreamingCall;
import static io.grpc.stub.ClientCalls.asyncUnaryCall;
import static io.grpc.stub.ClientCalls.blockingServerStreamingCall;
import static io.grpc.stub.ClientCalls.blockingUnaryCall;
import static io.grpc.stub.ClientCalls.futureUnaryCall;
import static io.grpc.stub.ServerCalls.asyncBidiStreamingCall;
import static io.grpc.stub.ServerCalls.asyncClientStreamingCall;
import static io.grpc.stub.ServerCalls.asyncServerStreamingCall;
import static io.grpc.stub.ServerCalls.asyncUnaryCall;
import static io.grpc.stub.ServerCalls.asyncUnimplementedStreamingCall;
import static io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall;

/**
 * <pre>
 ************************* ApplicationAdminService *****************************
 * </pre>
 */
@javax.annotation.Generated(
    value = "by gRPC proto compiler (version 1.19.0)",
    comments = "Source: admin.proto")
public final class ApplicationAdminServiceGrpc {

  private ApplicationAdminServiceGrpc() {}

  public static final String SERVICE_NAME = "io.axoniq.axonserver.grpc.admin.ApplicationAdminService";

  // Static method descriptors that strictly reflect the proto.
  private static volatile io.grpc.MethodDescriptor<io.axoniq.axonserver.grpc.admin.ApplicationRequest,
      io.axoniq.axonserver.grpc.admin.Token> getCreateOrUpdateApplicationMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "CreateOrUpdateApplication",
      requestType = io.axoniq.axonserver.grpc.admin.ApplicationRequest.class,
      responseType = io.axoniq.axonserver.grpc.admin.Token.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<io.axoniq.axonserver.grpc.admin.ApplicationRequest,
      io.axoniq.axonserver.grpc.admin.Token> getCreateOrUpdateApplicationMethod() {
    io.grpc.MethodDescriptor<io.axoniq.axonserver.grpc.admin.ApplicationRequest, io.axoniq.axonserver.grpc.admin.Token> getCreateOrUpdateApplicationMethod;
    if ((getCreateOrUpdateApplicationMethod = ApplicationAdminServiceGrpc.getCreateOrUpdateApplicationMethod) == null) {
      synchronized (ApplicationAdminServiceGrpc.class) {
        if ((getCreateOrUpdateApplicationMethod = ApplicationAdminServiceGrpc.getCreateOrUpdateApplicationMethod) == null) {
          ApplicationAdminServiceGrpc.getCreateOrUpdateApplicationMethod = getCreateOrUpdateApplicationMethod = 
              io.grpc.MethodDescriptor.<io.axoniq.axonserver.grpc.admin.ApplicationRequest, io.axoniq.axonserver.grpc.admin.Token>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "io.axoniq.axonserver.grpc.admin.ApplicationAdminService", "CreateOrUpdateApplication"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  io.axoniq.axonserver.grpc.admin.ApplicationRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  io.axoniq.axonserver.grpc.admin.Token.getDefaultInstance()))
                  .setSchemaDescriptor(new ApplicationAdminServiceMethodDescriptorSupplier("CreateOrUpdateApplication"))
                  .build();
          }
        }
     }
     return getCreateOrUpdateApplicationMethod;
  }

  private static volatile io.grpc.MethodDescriptor<io.axoniq.axonserver.grpc.admin.ApplicationId,
      com.google.protobuf.Empty> getDeleteApplicationMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "DeleteApplication",
      requestType = io.axoniq.axonserver.grpc.admin.ApplicationId.class,
      responseType = com.google.protobuf.Empty.class,
      methodType = io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
  public static io.grpc.MethodDescriptor<io.axoniq.axonserver.grpc.admin.ApplicationId,
      com.google.protobuf.Empty> getDeleteApplicationMethod() {
    io.grpc.MethodDescriptor<io.axoniq.axonserver.grpc.admin.ApplicationId, com.google.protobuf.Empty> getDeleteApplicationMethod;
    if ((getDeleteApplicationMethod = ApplicationAdminServiceGrpc.getDeleteApplicationMethod) == null) {
      synchronized (ApplicationAdminServiceGrpc.class) {
        if ((getDeleteApplicationMethod = ApplicationAdminServiceGrpc.getDeleteApplicationMethod) == null) {
          ApplicationAdminServiceGrpc.getDeleteApplicationMethod = getDeleteApplicationMethod = 
              io.grpc.MethodDescriptor.<io.axoniq.axonserver.grpc.admin.ApplicationId, com.google.protobuf.Empty>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
              .setFullMethodName(generateFullMethodName(
                  "io.axoniq.axonserver.grpc.admin.ApplicationAdminService", "DeleteApplication"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  io.axoniq.axonserver.grpc.admin.ApplicationId.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.protobuf.Empty.getDefaultInstance()))
                  .setSchemaDescriptor(new ApplicationAdminServiceMethodDescriptorSupplier("DeleteApplication"))
                  .build();
          }
        }
     }
     return getDeleteApplicationMethod;
  }

  private static volatile io.grpc.MethodDescriptor<io.axoniq.axonserver.grpc.admin.ApplicationId,
      io.axoniq.axonserver.grpc.admin.ApplicationOverview> getGetApplicationMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetApplication",
      requestType = io.axoniq.axonserver.grpc.admin.ApplicationId.class,
      responseType = io.axoniq.axonserver.grpc.admin.ApplicationOverview.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<io.axoniq.axonserver.grpc.admin.ApplicationId,
      io.axoniq.axonserver.grpc.admin.ApplicationOverview> getGetApplicationMethod() {
    io.grpc.MethodDescriptor<io.axoniq.axonserver.grpc.admin.ApplicationId, io.axoniq.axonserver.grpc.admin.ApplicationOverview> getGetApplicationMethod;
    if ((getGetApplicationMethod = ApplicationAdminServiceGrpc.getGetApplicationMethod) == null) {
      synchronized (ApplicationAdminServiceGrpc.class) {
        if ((getGetApplicationMethod = ApplicationAdminServiceGrpc.getGetApplicationMethod) == null) {
          ApplicationAdminServiceGrpc.getGetApplicationMethod = getGetApplicationMethod = 
              io.grpc.MethodDescriptor.<io.axoniq.axonserver.grpc.admin.ApplicationId, io.axoniq.axonserver.grpc.admin.ApplicationOverview>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "io.axoniq.axonserver.grpc.admin.ApplicationAdminService", "GetApplication"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  io.axoniq.axonserver.grpc.admin.ApplicationId.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  io.axoniq.axonserver.grpc.admin.ApplicationOverview.getDefaultInstance()))
                  .setSchemaDescriptor(new ApplicationAdminServiceMethodDescriptorSupplier("GetApplication"))
                  .build();
          }
        }
     }
     return getGetApplicationMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.google.protobuf.Empty,
      io.axoniq.axonserver.grpc.admin.ApplicationOverview> getGetApplicationsMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetApplications",
      requestType = com.google.protobuf.Empty.class,
      responseType = io.axoniq.axonserver.grpc.admin.ApplicationOverview.class,
      methodType = io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
  public static io.grpc.MethodDescriptor<com.google.protobuf.Empty,
      io.axoniq.axonserver.grpc.admin.ApplicationOverview> getGetApplicationsMethod() {
    io.grpc.MethodDescriptor<com.google.protobuf.Empty, io.axoniq.axonserver.grpc.admin.ApplicationOverview> getGetApplicationsMethod;
    if ((getGetApplicationsMethod = ApplicationAdminServiceGrpc.getGetApplicationsMethod) == null) {
      synchronized (ApplicationAdminServiceGrpc.class) {
        if ((getGetApplicationsMethod = ApplicationAdminServiceGrpc.getGetApplicationsMethod) == null) {
          ApplicationAdminServiceGrpc.getGetApplicationsMethod = getGetApplicationsMethod = 
              io.grpc.MethodDescriptor.<com.google.protobuf.Empty, io.axoniq.axonserver.grpc.admin.ApplicationOverview>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
              .setFullMethodName(generateFullMethodName(
                  "io.axoniq.axonserver.grpc.admin.ApplicationAdminService", "GetApplications"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.protobuf.Empty.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  io.axoniq.axonserver.grpc.admin.ApplicationOverview.getDefaultInstance()))
                  .setSchemaDescriptor(new ApplicationAdminServiceMethodDescriptorSupplier("GetApplications"))
                  .build();
          }
        }
     }
     return getGetApplicationsMethod;
  }

  private static volatile io.grpc.MethodDescriptor<io.axoniq.axonserver.grpc.admin.ApplicationId,
      io.axoniq.axonserver.grpc.admin.Token> getRefreshTokenMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "RefreshToken",
      requestType = io.axoniq.axonserver.grpc.admin.ApplicationId.class,
      responseType = io.axoniq.axonserver.grpc.admin.Token.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<io.axoniq.axonserver.grpc.admin.ApplicationId,
      io.axoniq.axonserver.grpc.admin.Token> getRefreshTokenMethod() {
    io.grpc.MethodDescriptor<io.axoniq.axonserver.grpc.admin.ApplicationId, io.axoniq.axonserver.grpc.admin.Token> getRefreshTokenMethod;
    if ((getRefreshTokenMethod = ApplicationAdminServiceGrpc.getRefreshTokenMethod) == null) {
      synchronized (ApplicationAdminServiceGrpc.class) {
        if ((getRefreshTokenMethod = ApplicationAdminServiceGrpc.getRefreshTokenMethod) == null) {
          ApplicationAdminServiceGrpc.getRefreshTokenMethod = getRefreshTokenMethod = 
              io.grpc.MethodDescriptor.<io.axoniq.axonserver.grpc.admin.ApplicationId, io.axoniq.axonserver.grpc.admin.Token>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "io.axoniq.axonserver.grpc.admin.ApplicationAdminService", "RefreshToken"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  io.axoniq.axonserver.grpc.admin.ApplicationId.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  io.axoniq.axonserver.grpc.admin.Token.getDefaultInstance()))
                  .setSchemaDescriptor(new ApplicationAdminServiceMethodDescriptorSupplier("RefreshToken"))
                  .build();
          }
        }
     }
     return getRefreshTokenMethod;
  }

  private static volatile io.grpc.MethodDescriptor<io.axoniq.axonserver.grpc.admin.ContextId,
      io.axoniq.axonserver.grpc.admin.ConnectedApplicationOverview> getGetConnectedApplicationsByContextMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetConnectedApplicationsByContext",
      requestType = io.axoniq.axonserver.grpc.admin.ContextId.class,
      responseType = io.axoniq.axonserver.grpc.admin.ConnectedApplicationOverview.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<io.axoniq.axonserver.grpc.admin.ContextId,
      io.axoniq.axonserver.grpc.admin.ConnectedApplicationOverview> getGetConnectedApplicationsByContextMethod() {
    io.grpc.MethodDescriptor<io.axoniq.axonserver.grpc.admin.ContextId, io.axoniq.axonserver.grpc.admin.ConnectedApplicationOverview> getGetConnectedApplicationsByContextMethod;
    if ((getGetConnectedApplicationsByContextMethod = ApplicationAdminServiceGrpc.getGetConnectedApplicationsByContextMethod) == null) {
      synchronized (ApplicationAdminServiceGrpc.class) {
        if ((getGetConnectedApplicationsByContextMethod = ApplicationAdminServiceGrpc.getGetConnectedApplicationsByContextMethod) == null) {
          ApplicationAdminServiceGrpc.getGetConnectedApplicationsByContextMethod = getGetConnectedApplicationsByContextMethod = 
              io.grpc.MethodDescriptor.<io.axoniq.axonserver.grpc.admin.ContextId, io.axoniq.axonserver.grpc.admin.ConnectedApplicationOverview>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "io.axoniq.axonserver.grpc.admin.ApplicationAdminService", "GetConnectedApplicationsByContext"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  io.axoniq.axonserver.grpc.admin.ContextId.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  io.axoniq.axonserver.grpc.admin.ConnectedApplicationOverview.getDefaultInstance()))
                  .setSchemaDescriptor(new ApplicationAdminServiceMethodDescriptorSupplier("GetConnectedApplicationsByContext"))
                  .build();
          }
        }
     }
     return getGetConnectedApplicationsByContextMethod;
  }

  /**
   * Creates a new async stub that supports all call types for the service
   */
  public static ApplicationAdminServiceStub newStub(io.grpc.Channel channel) {
    return new ApplicationAdminServiceStub(channel);
  }

  /**
   * Creates a new blocking-style stub that supports unary and streaming output calls on the service
   */
  public static ApplicationAdminServiceBlockingStub newBlockingStub(
      io.grpc.Channel channel) {
    return new ApplicationAdminServiceBlockingStub(channel);
  }

  /**
   * Creates a new ListenableFuture-style stub that supports unary calls on the service
   */
  public static ApplicationAdminServiceFutureStub newFutureStub(
      io.grpc.Channel channel) {
    return new ApplicationAdminServiceFutureStub(channel);
  }

  /**
   * <pre>
   ************************* ApplicationAdminService *****************************
   * </pre>
   */
  public static abstract class ApplicationAdminServiceImplBase implements io.grpc.BindableService {

    /**
     */
    public void createOrUpdateApplication(io.axoniq.axonserver.grpc.admin.ApplicationRequest request,
        io.grpc.stub.StreamObserver<io.axoniq.axonserver.grpc.admin.Token> responseObserver) {
      asyncUnimplementedUnaryCall(getCreateOrUpdateApplicationMethod(), responseObserver);
    }

    /**
     */
    public void deleteApplication(io.axoniq.axonserver.grpc.admin.ApplicationId request,
        io.grpc.stub.StreamObserver<com.google.protobuf.Empty> responseObserver) {
      asyncUnimplementedUnaryCall(getDeleteApplicationMethod(), responseObserver);
    }

    /**
     */
    public void getApplication(io.axoniq.axonserver.grpc.admin.ApplicationId request,
        io.grpc.stub.StreamObserver<io.axoniq.axonserver.grpc.admin.ApplicationOverview> responseObserver) {
      asyncUnimplementedUnaryCall(getGetApplicationMethod(), responseObserver);
    }

    /**
     */
    public void getApplications(com.google.protobuf.Empty request,
        io.grpc.stub.StreamObserver<io.axoniq.axonserver.grpc.admin.ApplicationOverview> responseObserver) {
      asyncUnimplementedUnaryCall(getGetApplicationsMethod(), responseObserver);
    }

    /**
     */
    public void refreshToken(io.axoniq.axonserver.grpc.admin.ApplicationId request,
        io.grpc.stub.StreamObserver<io.axoniq.axonserver.grpc.admin.Token> responseObserver) {
      asyncUnimplementedUnaryCall(getRefreshTokenMethod(), responseObserver);
    }

    /**
     */
    public void getConnectedApplicationsByContext(io.axoniq.axonserver.grpc.admin.ContextId request,
        io.grpc.stub.StreamObserver<io.axoniq.axonserver.grpc.admin.ConnectedApplicationOverview> responseObserver) {
      asyncUnimplementedUnaryCall(getGetConnectedApplicationsByContextMethod(), responseObserver);
    }

    @java.lang.Override public final io.grpc.ServerServiceDefinition bindService() {
      return io.grpc.ServerServiceDefinition.builder(getServiceDescriptor())
          .addMethod(
            getCreateOrUpdateApplicationMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                io.axoniq.axonserver.grpc.admin.ApplicationRequest,
                io.axoniq.axonserver.grpc.admin.Token>(
                  this, METHODID_CREATE_OR_UPDATE_APPLICATION)))
          .addMethod(
            getDeleteApplicationMethod(),
            asyncServerStreamingCall(
              new MethodHandlers<
                io.axoniq.axonserver.grpc.admin.ApplicationId,
                com.google.protobuf.Empty>(
                  this, METHODID_DELETE_APPLICATION)))
          .addMethod(
            getGetApplicationMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                io.axoniq.axonserver.grpc.admin.ApplicationId,
                io.axoniq.axonserver.grpc.admin.ApplicationOverview>(
                  this, METHODID_GET_APPLICATION)))
          .addMethod(
            getGetApplicationsMethod(),
            asyncServerStreamingCall(
              new MethodHandlers<
                com.google.protobuf.Empty,
                io.axoniq.axonserver.grpc.admin.ApplicationOverview>(
                  this, METHODID_GET_APPLICATIONS)))
          .addMethod(
            getRefreshTokenMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                io.axoniq.axonserver.grpc.admin.ApplicationId,
                io.axoniq.axonserver.grpc.admin.Token>(
                  this, METHODID_REFRESH_TOKEN)))
          .addMethod(
            getGetConnectedApplicationsByContextMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                io.axoniq.axonserver.grpc.admin.ContextId,
                io.axoniq.axonserver.grpc.admin.ConnectedApplicationOverview>(
                  this, METHODID_GET_CONNECTED_APPLICATIONS_BY_CONTEXT)))
          .build();
    }
  }

  /**
   * <pre>
   ************************* ApplicationAdminService *****************************
   * </pre>
   */
  public static final class ApplicationAdminServiceStub extends io.grpc.stub.AbstractStub<ApplicationAdminServiceStub> {
    private ApplicationAdminServiceStub(io.grpc.Channel channel) {
      super(channel);
    }

    private ApplicationAdminServiceStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected ApplicationAdminServiceStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new ApplicationAdminServiceStub(channel, callOptions);
    }

    /**
     */
    public void createOrUpdateApplication(io.axoniq.axonserver.grpc.admin.ApplicationRequest request,
        io.grpc.stub.StreamObserver<io.axoniq.axonserver.grpc.admin.Token> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getCreateOrUpdateApplicationMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void deleteApplication(io.axoniq.axonserver.grpc.admin.ApplicationId request,
        io.grpc.stub.StreamObserver<com.google.protobuf.Empty> responseObserver) {
      asyncServerStreamingCall(
          getChannel().newCall(getDeleteApplicationMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void getApplication(io.axoniq.axonserver.grpc.admin.ApplicationId request,
        io.grpc.stub.StreamObserver<io.axoniq.axonserver.grpc.admin.ApplicationOverview> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getGetApplicationMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void getApplications(com.google.protobuf.Empty request,
        io.grpc.stub.StreamObserver<io.axoniq.axonserver.grpc.admin.ApplicationOverview> responseObserver) {
      asyncServerStreamingCall(
          getChannel().newCall(getGetApplicationsMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void refreshToken(io.axoniq.axonserver.grpc.admin.ApplicationId request,
        io.grpc.stub.StreamObserver<io.axoniq.axonserver.grpc.admin.Token> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getRefreshTokenMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void getConnectedApplicationsByContext(io.axoniq.axonserver.grpc.admin.ContextId request,
        io.grpc.stub.StreamObserver<io.axoniq.axonserver.grpc.admin.ConnectedApplicationOverview> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getGetConnectedApplicationsByContextMethod(), getCallOptions()), request, responseObserver);
    }
  }

  /**
   * <pre>
   ************************* ApplicationAdminService *****************************
   * </pre>
   */
  public static final class ApplicationAdminServiceBlockingStub extends io.grpc.stub.AbstractStub<ApplicationAdminServiceBlockingStub> {
    private ApplicationAdminServiceBlockingStub(io.grpc.Channel channel) {
      super(channel);
    }

    private ApplicationAdminServiceBlockingStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected ApplicationAdminServiceBlockingStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new ApplicationAdminServiceBlockingStub(channel, callOptions);
    }

    /**
     */
    public io.axoniq.axonserver.grpc.admin.Token createOrUpdateApplication(io.axoniq.axonserver.grpc.admin.ApplicationRequest request) {
      return blockingUnaryCall(
          getChannel(), getCreateOrUpdateApplicationMethod(), getCallOptions(), request);
    }

    /**
     */
    public java.util.Iterator<com.google.protobuf.Empty> deleteApplication(
        io.axoniq.axonserver.grpc.admin.ApplicationId request) {
      return blockingServerStreamingCall(
          getChannel(), getDeleteApplicationMethod(), getCallOptions(), request);
    }

    /**
     */
    public io.axoniq.axonserver.grpc.admin.ApplicationOverview getApplication(io.axoniq.axonserver.grpc.admin.ApplicationId request) {
      return blockingUnaryCall(
          getChannel(), getGetApplicationMethod(), getCallOptions(), request);
    }

    /**
     */
    public java.util.Iterator<io.axoniq.axonserver.grpc.admin.ApplicationOverview> getApplications(
        com.google.protobuf.Empty request) {
      return blockingServerStreamingCall(
          getChannel(), getGetApplicationsMethod(), getCallOptions(), request);
    }

    /**
     */
    public io.axoniq.axonserver.grpc.admin.Token refreshToken(io.axoniq.axonserver.grpc.admin.ApplicationId request) {
      return blockingUnaryCall(
          getChannel(), getRefreshTokenMethod(), getCallOptions(), request);
    }

    /**
     */
    public io.axoniq.axonserver.grpc.admin.ConnectedApplicationOverview getConnectedApplicationsByContext(io.axoniq.axonserver.grpc.admin.ContextId request) {
      return blockingUnaryCall(
          getChannel(), getGetConnectedApplicationsByContextMethod(), getCallOptions(), request);
    }
  }

  /**
   * <pre>
   ************************* ApplicationAdminService *****************************
   * </pre>
   */
  public static final class ApplicationAdminServiceFutureStub extends io.grpc.stub.AbstractStub<ApplicationAdminServiceFutureStub> {
    private ApplicationAdminServiceFutureStub(io.grpc.Channel channel) {
      super(channel);
    }

    private ApplicationAdminServiceFutureStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected ApplicationAdminServiceFutureStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new ApplicationAdminServiceFutureStub(channel, callOptions);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<io.axoniq.axonserver.grpc.admin.Token> createOrUpdateApplication(
        io.axoniq.axonserver.grpc.admin.ApplicationRequest request) {
      return futureUnaryCall(
          getChannel().newCall(getCreateOrUpdateApplicationMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<io.axoniq.axonserver.grpc.admin.ApplicationOverview> getApplication(
        io.axoniq.axonserver.grpc.admin.ApplicationId request) {
      return futureUnaryCall(
          getChannel().newCall(getGetApplicationMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<io.axoniq.axonserver.grpc.admin.Token> refreshToken(
        io.axoniq.axonserver.grpc.admin.ApplicationId request) {
      return futureUnaryCall(
          getChannel().newCall(getRefreshTokenMethod(), getCallOptions()), request);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<io.axoniq.axonserver.grpc.admin.ConnectedApplicationOverview> getConnectedApplicationsByContext(
        io.axoniq.axonserver.grpc.admin.ContextId request) {
      return futureUnaryCall(
          getChannel().newCall(getGetConnectedApplicationsByContextMethod(), getCallOptions()), request);
    }
  }

  private static final int METHODID_CREATE_OR_UPDATE_APPLICATION = 0;
  private static final int METHODID_DELETE_APPLICATION = 1;
  private static final int METHODID_GET_APPLICATION = 2;
  private static final int METHODID_GET_APPLICATIONS = 3;
  private static final int METHODID_REFRESH_TOKEN = 4;
  private static final int METHODID_GET_CONNECTED_APPLICATIONS_BY_CONTEXT = 5;

  private static final class MethodHandlers<Req, Resp> implements
      io.grpc.stub.ServerCalls.UnaryMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ServerStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ClientStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.BidiStreamingMethod<Req, Resp> {
    private final ApplicationAdminServiceImplBase serviceImpl;
    private final int methodId;

    MethodHandlers(ApplicationAdminServiceImplBase serviceImpl, int methodId) {
      this.serviceImpl = serviceImpl;
      this.methodId = methodId;
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public void invoke(Req request, io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_CREATE_OR_UPDATE_APPLICATION:
          serviceImpl.createOrUpdateApplication((io.axoniq.axonserver.grpc.admin.ApplicationRequest) request,
              (io.grpc.stub.StreamObserver<io.axoniq.axonserver.grpc.admin.Token>) responseObserver);
          break;
        case METHODID_DELETE_APPLICATION:
          serviceImpl.deleteApplication((io.axoniq.axonserver.grpc.admin.ApplicationId) request,
              (io.grpc.stub.StreamObserver<com.google.protobuf.Empty>) responseObserver);
          break;
        case METHODID_GET_APPLICATION:
          serviceImpl.getApplication((io.axoniq.axonserver.grpc.admin.ApplicationId) request,
              (io.grpc.stub.StreamObserver<io.axoniq.axonserver.grpc.admin.ApplicationOverview>) responseObserver);
          break;
        case METHODID_GET_APPLICATIONS:
          serviceImpl.getApplications((com.google.protobuf.Empty) request,
              (io.grpc.stub.StreamObserver<io.axoniq.axonserver.grpc.admin.ApplicationOverview>) responseObserver);
          break;
        case METHODID_REFRESH_TOKEN:
          serviceImpl.refreshToken((io.axoniq.axonserver.grpc.admin.ApplicationId) request,
              (io.grpc.stub.StreamObserver<io.axoniq.axonserver.grpc.admin.Token>) responseObserver);
          break;
        case METHODID_GET_CONNECTED_APPLICATIONS_BY_CONTEXT:
          serviceImpl.getConnectedApplicationsByContext((io.axoniq.axonserver.grpc.admin.ContextId) request,
              (io.grpc.stub.StreamObserver<io.axoniq.axonserver.grpc.admin.ConnectedApplicationOverview>) responseObserver);
          break;
        default:
          throw new AssertionError();
      }
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public io.grpc.stub.StreamObserver<Req> invoke(
        io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        default:
          throw new AssertionError();
      }
    }
  }

  private static abstract class ApplicationAdminServiceBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoFileDescriptorSupplier, io.grpc.protobuf.ProtoServiceDescriptorSupplier {
    ApplicationAdminServiceBaseDescriptorSupplier() {}

    @java.lang.Override
    public com.google.protobuf.Descriptors.FileDescriptor getFileDescriptor() {
      return io.axoniq.axonserver.grpc.admin.Admin.getDescriptor();
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.ServiceDescriptor getServiceDescriptor() {
      return getFileDescriptor().findServiceByName("ApplicationAdminService");
    }
  }

  private static final class ApplicationAdminServiceFileDescriptorSupplier
      extends ApplicationAdminServiceBaseDescriptorSupplier {
    ApplicationAdminServiceFileDescriptorSupplier() {}
  }

  private static final class ApplicationAdminServiceMethodDescriptorSupplier
      extends ApplicationAdminServiceBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoMethodDescriptorSupplier {
    private final String methodName;

    ApplicationAdminServiceMethodDescriptorSupplier(String methodName) {
      this.methodName = methodName;
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.MethodDescriptor getMethodDescriptor() {
      return getServiceDescriptor().findMethodByName(methodName);
    }
  }

  private static volatile io.grpc.ServiceDescriptor serviceDescriptor;

  public static io.grpc.ServiceDescriptor getServiceDescriptor() {
    io.grpc.ServiceDescriptor result = serviceDescriptor;
    if (result == null) {
      synchronized (ApplicationAdminServiceGrpc.class) {
        result = serviceDescriptor;
        if (result == null) {
          serviceDescriptor = result = io.grpc.ServiceDescriptor.newBuilder(SERVICE_NAME)
              .setSchemaDescriptor(new ApplicationAdminServiceFileDescriptorSupplier())
              .addMethod(getCreateOrUpdateApplicationMethod())
              .addMethod(getDeleteApplicationMethod())
              .addMethod(getGetApplicationMethod())
              .addMethod(getGetApplicationsMethod())
              .addMethod(getRefreshTokenMethod())
              .addMethod(getGetConnectedApplicationsByContextMethod())
              .build();
        }
      }
    }
    return result;
  }
}

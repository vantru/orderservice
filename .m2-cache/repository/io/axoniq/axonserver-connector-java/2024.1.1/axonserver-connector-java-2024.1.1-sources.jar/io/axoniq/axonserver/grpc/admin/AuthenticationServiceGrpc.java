package io.axoniq.axonserver.grpc.admin;

import static io.grpc.MethodDescriptor.generateFullMethodName;
import static io.grpc.stub.ClientCalls.asyncBidiStreamingCall;
import static io.grpc.stub.ClientCalls.asyncClientStreamingCall;
import static io.grpc.stub.ClientCalls.asyncServerStreamingCall;
import static io.grpc.stub.ClientCalls.asyncUnaryCall;
import static io.grpc.stub.ClientCalls.blockingServerStreamingCall;
import static io.grpc.stub.ClientCalls.blockingUnaryCall;
import static io.grpc.stub.ClientCalls.futureUnaryCall;
import static io.grpc.stub.ServerCalls.asyncBidiStreamingCall;
import static io.grpc.stub.ServerCalls.asyncClientStreamingCall;
import static io.grpc.stub.ServerCalls.asyncServerStreamingCall;
import static io.grpc.stub.ServerCalls.asyncUnaryCall;
import static io.grpc.stub.ServerCalls.asyncUnimplementedStreamingCall;
import static io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall;

/**
 * <pre>
 * AuthenticationService, allows to use Axon Server as authentication provider 
 * </pre>
 */
@javax.annotation.Generated(
    value = "by gRPC proto compiler (version 1.19.0)",
    comments = "Source: admin.proto")
public final class AuthenticationServiceGrpc {

  private AuthenticationServiceGrpc() {}

  public static final String SERVICE_NAME = "io.axoniq.axonserver.grpc.admin.AuthenticationService";

  // Static method descriptors that strictly reflect the proto.
  private static volatile io.grpc.MethodDescriptor<io.axoniq.axonserver.grpc.admin.AuthenticateUserRequest,
      io.axoniq.axonserver.grpc.admin.UserRoles> getAuthenticateUserMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "AuthenticateUser",
      requestType = io.axoniq.axonserver.grpc.admin.AuthenticateUserRequest.class,
      responseType = io.axoniq.axonserver.grpc.admin.UserRoles.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<io.axoniq.axonserver.grpc.admin.AuthenticateUserRequest,
      io.axoniq.axonserver.grpc.admin.UserRoles> getAuthenticateUserMethod() {
    io.grpc.MethodDescriptor<io.axoniq.axonserver.grpc.admin.AuthenticateUserRequest, io.axoniq.axonserver.grpc.admin.UserRoles> getAuthenticateUserMethod;
    if ((getAuthenticateUserMethod = AuthenticationServiceGrpc.getAuthenticateUserMethod) == null) {
      synchronized (AuthenticationServiceGrpc.class) {
        if ((getAuthenticateUserMethod = AuthenticationServiceGrpc.getAuthenticateUserMethod) == null) {
          AuthenticationServiceGrpc.getAuthenticateUserMethod = getAuthenticateUserMethod = 
              io.grpc.MethodDescriptor.<io.axoniq.axonserver.grpc.admin.AuthenticateUserRequest, io.axoniq.axonserver.grpc.admin.UserRoles>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "io.axoniq.axonserver.grpc.admin.AuthenticationService", "AuthenticateUser"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  io.axoniq.axonserver.grpc.admin.AuthenticateUserRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  io.axoniq.axonserver.grpc.admin.UserRoles.getDefaultInstance()))
                  .setSchemaDescriptor(new AuthenticationServiceMethodDescriptorSupplier("AuthenticateUser"))
                  .build();
          }
        }
     }
     return getAuthenticateUserMethod;
  }

  private static volatile io.grpc.MethodDescriptor<io.axoniq.axonserver.grpc.admin.Token,
      io.axoniq.axonserver.grpc.admin.ApplicationRoles> getAuthenticateTokenMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "AuthenticateToken",
      requestType = io.axoniq.axonserver.grpc.admin.Token.class,
      responseType = io.axoniq.axonserver.grpc.admin.ApplicationRoles.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<io.axoniq.axonserver.grpc.admin.Token,
      io.axoniq.axonserver.grpc.admin.ApplicationRoles> getAuthenticateTokenMethod() {
    io.grpc.MethodDescriptor<io.axoniq.axonserver.grpc.admin.Token, io.axoniq.axonserver.grpc.admin.ApplicationRoles> getAuthenticateTokenMethod;
    if ((getAuthenticateTokenMethod = AuthenticationServiceGrpc.getAuthenticateTokenMethod) == null) {
      synchronized (AuthenticationServiceGrpc.class) {
        if ((getAuthenticateTokenMethod = AuthenticationServiceGrpc.getAuthenticateTokenMethod) == null) {
          AuthenticationServiceGrpc.getAuthenticateTokenMethod = getAuthenticateTokenMethod = 
              io.grpc.MethodDescriptor.<io.axoniq.axonserver.grpc.admin.Token, io.axoniq.axonserver.grpc.admin.ApplicationRoles>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "io.axoniq.axonserver.grpc.admin.AuthenticationService", "AuthenticateToken"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  io.axoniq.axonserver.grpc.admin.Token.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  io.axoniq.axonserver.grpc.admin.ApplicationRoles.getDefaultInstance()))
                  .setSchemaDescriptor(new AuthenticationServiceMethodDescriptorSupplier("AuthenticateToken"))
                  .build();
          }
        }
     }
     return getAuthenticateTokenMethod;
  }

  /**
   * Creates a new async stub that supports all call types for the service
   */
  public static AuthenticationServiceStub newStub(io.grpc.Channel channel) {
    return new AuthenticationServiceStub(channel);
  }

  /**
   * Creates a new blocking-style stub that supports unary and streaming output calls on the service
   */
  public static AuthenticationServiceBlockingStub newBlockingStub(
      io.grpc.Channel channel) {
    return new AuthenticationServiceBlockingStub(channel);
  }

  /**
   * Creates a new ListenableFuture-style stub that supports unary calls on the service
   */
  public static AuthenticationServiceFutureStub newFutureStub(
      io.grpc.Channel channel) {
    return new AuthenticationServiceFutureStub(channel);
  }

  /**
   * <pre>
   * AuthenticationService, allows to use Axon Server as authentication provider 
   * </pre>
   */
  public static abstract class AuthenticationServiceImplBase implements io.grpc.BindableService {

    /**
     * <pre>
     * Authenticate a user, returns the user's roles 
     * </pre>
     */
    public void authenticateUser(io.axoniq.axonserver.grpc.admin.AuthenticateUserRequest request,
        io.grpc.stub.StreamObserver<io.axoniq.axonserver.grpc.admin.UserRoles> responseObserver) {
      asyncUnimplementedUnaryCall(getAuthenticateUserMethod(), responseObserver);
    }

    /**
     * <pre>
     * Authenticate based on an application token, returns the application's roles 
     * </pre>
     */
    public void authenticateToken(io.axoniq.axonserver.grpc.admin.Token request,
        io.grpc.stub.StreamObserver<io.axoniq.axonserver.grpc.admin.ApplicationRoles> responseObserver) {
      asyncUnimplementedUnaryCall(getAuthenticateTokenMethod(), responseObserver);
    }

    @java.lang.Override public final io.grpc.ServerServiceDefinition bindService() {
      return io.grpc.ServerServiceDefinition.builder(getServiceDescriptor())
          .addMethod(
            getAuthenticateUserMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                io.axoniq.axonserver.grpc.admin.AuthenticateUserRequest,
                io.axoniq.axonserver.grpc.admin.UserRoles>(
                  this, METHODID_AUTHENTICATE_USER)))
          .addMethod(
            getAuthenticateTokenMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                io.axoniq.axonserver.grpc.admin.Token,
                io.axoniq.axonserver.grpc.admin.ApplicationRoles>(
                  this, METHODID_AUTHENTICATE_TOKEN)))
          .build();
    }
  }

  /**
   * <pre>
   * AuthenticationService, allows to use Axon Server as authentication provider 
   * </pre>
   */
  public static final class AuthenticationServiceStub extends io.grpc.stub.AbstractStub<AuthenticationServiceStub> {
    private AuthenticationServiceStub(io.grpc.Channel channel) {
      super(channel);
    }

    private AuthenticationServiceStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected AuthenticationServiceStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new AuthenticationServiceStub(channel, callOptions);
    }

    /**
     * <pre>
     * Authenticate a user, returns the user's roles 
     * </pre>
     */
    public void authenticateUser(io.axoniq.axonserver.grpc.admin.AuthenticateUserRequest request,
        io.grpc.stub.StreamObserver<io.axoniq.axonserver.grpc.admin.UserRoles> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getAuthenticateUserMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Authenticate based on an application token, returns the application's roles 
     * </pre>
     */
    public void authenticateToken(io.axoniq.axonserver.grpc.admin.Token request,
        io.grpc.stub.StreamObserver<io.axoniq.axonserver.grpc.admin.ApplicationRoles> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getAuthenticateTokenMethod(), getCallOptions()), request, responseObserver);
    }
  }

  /**
   * <pre>
   * AuthenticationService, allows to use Axon Server as authentication provider 
   * </pre>
   */
  public static final class AuthenticationServiceBlockingStub extends io.grpc.stub.AbstractStub<AuthenticationServiceBlockingStub> {
    private AuthenticationServiceBlockingStub(io.grpc.Channel channel) {
      super(channel);
    }

    private AuthenticationServiceBlockingStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected AuthenticationServiceBlockingStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new AuthenticationServiceBlockingStub(channel, callOptions);
    }

    /**
     * <pre>
     * Authenticate a user, returns the user's roles 
     * </pre>
     */
    public io.axoniq.axonserver.grpc.admin.UserRoles authenticateUser(io.axoniq.axonserver.grpc.admin.AuthenticateUserRequest request) {
      return blockingUnaryCall(
          getChannel(), getAuthenticateUserMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Authenticate based on an application token, returns the application's roles 
     * </pre>
     */
    public io.axoniq.axonserver.grpc.admin.ApplicationRoles authenticateToken(io.axoniq.axonserver.grpc.admin.Token request) {
      return blockingUnaryCall(
          getChannel(), getAuthenticateTokenMethod(), getCallOptions(), request);
    }
  }

  /**
   * <pre>
   * AuthenticationService, allows to use Axon Server as authentication provider 
   * </pre>
   */
  public static final class AuthenticationServiceFutureStub extends io.grpc.stub.AbstractStub<AuthenticationServiceFutureStub> {
    private AuthenticationServiceFutureStub(io.grpc.Channel channel) {
      super(channel);
    }

    private AuthenticationServiceFutureStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected AuthenticationServiceFutureStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new AuthenticationServiceFutureStub(channel, callOptions);
    }

    /**
     * <pre>
     * Authenticate a user, returns the user's roles 
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<io.axoniq.axonserver.grpc.admin.UserRoles> authenticateUser(
        io.axoniq.axonserver.grpc.admin.AuthenticateUserRequest request) {
      return futureUnaryCall(
          getChannel().newCall(getAuthenticateUserMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Authenticate based on an application token, returns the application's roles 
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<io.axoniq.axonserver.grpc.admin.ApplicationRoles> authenticateToken(
        io.axoniq.axonserver.grpc.admin.Token request) {
      return futureUnaryCall(
          getChannel().newCall(getAuthenticateTokenMethod(), getCallOptions()), request);
    }
  }

  private static final int METHODID_AUTHENTICATE_USER = 0;
  private static final int METHODID_AUTHENTICATE_TOKEN = 1;

  private static final class MethodHandlers<Req, Resp> implements
      io.grpc.stub.ServerCalls.UnaryMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ServerStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ClientStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.BidiStreamingMethod<Req, Resp> {
    private final AuthenticationServiceImplBase serviceImpl;
    private final int methodId;

    MethodHandlers(AuthenticationServiceImplBase serviceImpl, int methodId) {
      this.serviceImpl = serviceImpl;
      this.methodId = methodId;
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public void invoke(Req request, io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_AUTHENTICATE_USER:
          serviceImpl.authenticateUser((io.axoniq.axonserver.grpc.admin.AuthenticateUserRequest) request,
              (io.grpc.stub.StreamObserver<io.axoniq.axonserver.grpc.admin.UserRoles>) responseObserver);
          break;
        case METHODID_AUTHENTICATE_TOKEN:
          serviceImpl.authenticateToken((io.axoniq.axonserver.grpc.admin.Token) request,
              (io.grpc.stub.StreamObserver<io.axoniq.axonserver.grpc.admin.ApplicationRoles>) responseObserver);
          break;
        default:
          throw new AssertionError();
      }
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public io.grpc.stub.StreamObserver<Req> invoke(
        io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        default:
          throw new AssertionError();
      }
    }
  }

  private static abstract class AuthenticationServiceBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoFileDescriptorSupplier, io.grpc.protobuf.ProtoServiceDescriptorSupplier {
    AuthenticationServiceBaseDescriptorSupplier() {}

    @java.lang.Override
    public com.google.protobuf.Descriptors.FileDescriptor getFileDescriptor() {
      return io.axoniq.axonserver.grpc.admin.Admin.getDescriptor();
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.ServiceDescriptor getServiceDescriptor() {
      return getFileDescriptor().findServiceByName("AuthenticationService");
    }
  }

  private static final class AuthenticationServiceFileDescriptorSupplier
      extends AuthenticationServiceBaseDescriptorSupplier {
    AuthenticationServiceFileDescriptorSupplier() {}
  }

  private static final class AuthenticationServiceMethodDescriptorSupplier
      extends AuthenticationServiceBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoMethodDescriptorSupplier {
    private final String methodName;

    AuthenticationServiceMethodDescriptorSupplier(String methodName) {
      this.methodName = methodName;
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.MethodDescriptor getMethodDescriptor() {
      return getServiceDescriptor().findMethodByName(methodName);
    }
  }

  private static volatile io.grpc.ServiceDescriptor serviceDescriptor;

  public static io.grpc.ServiceDescriptor getServiceDescriptor() {
    io.grpc.ServiceDescriptor result = serviceDescriptor;
    if (result == null) {
      synchronized (AuthenticationServiceGrpc.class) {
        result = serviceDescriptor;
        if (result == null) {
          serviceDescriptor = result = io.grpc.ServiceDescriptor.newBuilder(SERVICE_NAME)
              .setSchemaDescriptor(new AuthenticationServiceFileDescriptorSupplier())
              .addMethod(getAuthenticateUserMethod())
              .addMethod(getAuthenticateTokenMethod())
              .build();
        }
      }
    }
    return result;
  }
}

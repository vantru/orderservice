package io.axoniq.axonserver.grpc.admin;

import static io.grpc.MethodDescriptor.generateFullMethodName;
import static io.grpc.stub.ClientCalls.asyncBidiStreamingCall;
import static io.grpc.stub.ClientCalls.asyncClientStreamingCall;
import static io.grpc.stub.ClientCalls.asyncServerStreamingCall;
import static io.grpc.stub.ClientCalls.asyncUnaryCall;
import static io.grpc.stub.ClientCalls.blockingServerStreamingCall;
import static io.grpc.stub.ClientCalls.blockingUnaryCall;
import static io.grpc.stub.ClientCalls.futureUnaryCall;
import static io.grpc.stub.ServerCalls.asyncBidiStreamingCall;
import static io.grpc.stub.ServerCalls.asyncClientStreamingCall;
import static io.grpc.stub.ServerCalls.asyncServerStreamingCall;
import static io.grpc.stub.ServerCalls.asyncUnaryCall;
import static io.grpc.stub.ServerCalls.asyncUnimplementedStreamingCall;
import static io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall;

/**
 * <pre>
 ************************* ContextAdminService *****************************
 * </pre>
 */
@javax.annotation.Generated(
    value = "by gRPC proto compiler (version 1.19.0)",
    comments = "Source: admin.proto")
public final class ContextAdminServiceGrpc {

  private ContextAdminServiceGrpc() {}

  public static final String SERVICE_NAME = "io.axoniq.axonserver.grpc.admin.ContextAdminService";

  // Static method descriptors that strictly reflect the proto.
  private static volatile io.grpc.MethodDescriptor<io.axoniq.axonserver.grpc.admin.CreateContextRequest,
      com.google.protobuf.Empty> getCreateContextMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "CreateContext",
      requestType = io.axoniq.axonserver.grpc.admin.CreateContextRequest.class,
      responseType = com.google.protobuf.Empty.class,
      methodType = io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
  public static io.grpc.MethodDescriptor<io.axoniq.axonserver.grpc.admin.CreateContextRequest,
      com.google.protobuf.Empty> getCreateContextMethod() {
    io.grpc.MethodDescriptor<io.axoniq.axonserver.grpc.admin.CreateContextRequest, com.google.protobuf.Empty> getCreateContextMethod;
    if ((getCreateContextMethod = ContextAdminServiceGrpc.getCreateContextMethod) == null) {
      synchronized (ContextAdminServiceGrpc.class) {
        if ((getCreateContextMethod = ContextAdminServiceGrpc.getCreateContextMethod) == null) {
          ContextAdminServiceGrpc.getCreateContextMethod = getCreateContextMethod = 
              io.grpc.MethodDescriptor.<io.axoniq.axonserver.grpc.admin.CreateContextRequest, com.google.protobuf.Empty>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
              .setFullMethodName(generateFullMethodName(
                  "io.axoniq.axonserver.grpc.admin.ContextAdminService", "CreateContext"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  io.axoniq.axonserver.grpc.admin.CreateContextRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.protobuf.Empty.getDefaultInstance()))
                  .setSchemaDescriptor(new ContextAdminServiceMethodDescriptorSupplier("CreateContext"))
                  .build();
          }
        }
     }
     return getCreateContextMethod;
  }

  private static volatile io.grpc.MethodDescriptor<io.axoniq.axonserver.grpc.admin.UpdateContextPropertiesRequest,
      com.google.protobuf.Empty> getUpdateContextPropertiesMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "UpdateContextProperties",
      requestType = io.axoniq.axonserver.grpc.admin.UpdateContextPropertiesRequest.class,
      responseType = com.google.protobuf.Empty.class,
      methodType = io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
  public static io.grpc.MethodDescriptor<io.axoniq.axonserver.grpc.admin.UpdateContextPropertiesRequest,
      com.google.protobuf.Empty> getUpdateContextPropertiesMethod() {
    io.grpc.MethodDescriptor<io.axoniq.axonserver.grpc.admin.UpdateContextPropertiesRequest, com.google.protobuf.Empty> getUpdateContextPropertiesMethod;
    if ((getUpdateContextPropertiesMethod = ContextAdminServiceGrpc.getUpdateContextPropertiesMethod) == null) {
      synchronized (ContextAdminServiceGrpc.class) {
        if ((getUpdateContextPropertiesMethod = ContextAdminServiceGrpc.getUpdateContextPropertiesMethod) == null) {
          ContextAdminServiceGrpc.getUpdateContextPropertiesMethod = getUpdateContextPropertiesMethod = 
              io.grpc.MethodDescriptor.<io.axoniq.axonserver.grpc.admin.UpdateContextPropertiesRequest, com.google.protobuf.Empty>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
              .setFullMethodName(generateFullMethodName(
                  "io.axoniq.axonserver.grpc.admin.ContextAdminService", "UpdateContextProperties"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  io.axoniq.axonserver.grpc.admin.UpdateContextPropertiesRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.protobuf.Empty.getDefaultInstance()))
                  .setSchemaDescriptor(new ContextAdminServiceMethodDescriptorSupplier("UpdateContextProperties"))
                  .build();
          }
        }
     }
     return getUpdateContextPropertiesMethod;
  }

  private static volatile io.grpc.MethodDescriptor<io.axoniq.axonserver.grpc.admin.DeleteContextRequest,
      com.google.protobuf.Empty> getDeleteContextMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "DeleteContext",
      requestType = io.axoniq.axonserver.grpc.admin.DeleteContextRequest.class,
      responseType = com.google.protobuf.Empty.class,
      methodType = io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
  public static io.grpc.MethodDescriptor<io.axoniq.axonserver.grpc.admin.DeleteContextRequest,
      com.google.protobuf.Empty> getDeleteContextMethod() {
    io.grpc.MethodDescriptor<io.axoniq.axonserver.grpc.admin.DeleteContextRequest, com.google.protobuf.Empty> getDeleteContextMethod;
    if ((getDeleteContextMethod = ContextAdminServiceGrpc.getDeleteContextMethod) == null) {
      synchronized (ContextAdminServiceGrpc.class) {
        if ((getDeleteContextMethod = ContextAdminServiceGrpc.getDeleteContextMethod) == null) {
          ContextAdminServiceGrpc.getDeleteContextMethod = getDeleteContextMethod = 
              io.grpc.MethodDescriptor.<io.axoniq.axonserver.grpc.admin.DeleteContextRequest, com.google.protobuf.Empty>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
              .setFullMethodName(generateFullMethodName(
                  "io.axoniq.axonserver.grpc.admin.ContextAdminService", "DeleteContext"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  io.axoniq.axonserver.grpc.admin.DeleteContextRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.protobuf.Empty.getDefaultInstance()))
                  .setSchemaDescriptor(new ContextAdminServiceMethodDescriptorSupplier("DeleteContext"))
                  .build();
          }
        }
     }
     return getDeleteContextMethod;
  }

  private static volatile io.grpc.MethodDescriptor<io.axoniq.axonserver.grpc.admin.GetContextRequest,
      io.axoniq.axonserver.grpc.admin.ContextOverview> getGetContextMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetContext",
      requestType = io.axoniq.axonserver.grpc.admin.GetContextRequest.class,
      responseType = io.axoniq.axonserver.grpc.admin.ContextOverview.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<io.axoniq.axonserver.grpc.admin.GetContextRequest,
      io.axoniq.axonserver.grpc.admin.ContextOverview> getGetContextMethod() {
    io.grpc.MethodDescriptor<io.axoniq.axonserver.grpc.admin.GetContextRequest, io.axoniq.axonserver.grpc.admin.ContextOverview> getGetContextMethod;
    if ((getGetContextMethod = ContextAdminServiceGrpc.getGetContextMethod) == null) {
      synchronized (ContextAdminServiceGrpc.class) {
        if ((getGetContextMethod = ContextAdminServiceGrpc.getGetContextMethod) == null) {
          ContextAdminServiceGrpc.getGetContextMethod = getGetContextMethod = 
              io.grpc.MethodDescriptor.<io.axoniq.axonserver.grpc.admin.GetContextRequest, io.axoniq.axonserver.grpc.admin.ContextOverview>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "io.axoniq.axonserver.grpc.admin.ContextAdminService", "GetContext"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  io.axoniq.axonserver.grpc.admin.GetContextRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  io.axoniq.axonserver.grpc.admin.ContextOverview.getDefaultInstance()))
                  .setSchemaDescriptor(new ContextAdminServiceMethodDescriptorSupplier("GetContext"))
                  .build();
          }
        }
     }
     return getGetContextMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.google.protobuf.Empty,
      io.axoniq.axonserver.grpc.admin.ContextOverview> getGetContextsMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetContexts",
      requestType = com.google.protobuf.Empty.class,
      responseType = io.axoniq.axonserver.grpc.admin.ContextOverview.class,
      methodType = io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
  public static io.grpc.MethodDescriptor<com.google.protobuf.Empty,
      io.axoniq.axonserver.grpc.admin.ContextOverview> getGetContextsMethod() {
    io.grpc.MethodDescriptor<com.google.protobuf.Empty, io.axoniq.axonserver.grpc.admin.ContextOverview> getGetContextsMethod;
    if ((getGetContextsMethod = ContextAdminServiceGrpc.getGetContextsMethod) == null) {
      synchronized (ContextAdminServiceGrpc.class) {
        if ((getGetContextsMethod = ContextAdminServiceGrpc.getGetContextsMethod) == null) {
          ContextAdminServiceGrpc.getGetContextsMethod = getGetContextsMethod = 
              io.grpc.MethodDescriptor.<com.google.protobuf.Empty, io.axoniq.axonserver.grpc.admin.ContextOverview>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
              .setFullMethodName(generateFullMethodName(
                  "io.axoniq.axonserver.grpc.admin.ContextAdminService", "GetContexts"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.protobuf.Empty.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  io.axoniq.axonserver.grpc.admin.ContextOverview.getDefaultInstance()))
                  .setSchemaDescriptor(new ContextAdminServiceMethodDescriptorSupplier("GetContexts"))
                  .build();
          }
        }
     }
     return getGetContextsMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.google.protobuf.Empty,
      io.axoniq.axonserver.grpc.admin.ContextUpdate> getSubscribeContextUpdatesMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "SubscribeContextUpdates",
      requestType = com.google.protobuf.Empty.class,
      responseType = io.axoniq.axonserver.grpc.admin.ContextUpdate.class,
      methodType = io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
  public static io.grpc.MethodDescriptor<com.google.protobuf.Empty,
      io.axoniq.axonserver.grpc.admin.ContextUpdate> getSubscribeContextUpdatesMethod() {
    io.grpc.MethodDescriptor<com.google.protobuf.Empty, io.axoniq.axonserver.grpc.admin.ContextUpdate> getSubscribeContextUpdatesMethod;
    if ((getSubscribeContextUpdatesMethod = ContextAdminServiceGrpc.getSubscribeContextUpdatesMethod) == null) {
      synchronized (ContextAdminServiceGrpc.class) {
        if ((getSubscribeContextUpdatesMethod = ContextAdminServiceGrpc.getSubscribeContextUpdatesMethod) == null) {
          ContextAdminServiceGrpc.getSubscribeContextUpdatesMethod = getSubscribeContextUpdatesMethod = 
              io.grpc.MethodDescriptor.<com.google.protobuf.Empty, io.axoniq.axonserver.grpc.admin.ContextUpdate>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
              .setFullMethodName(generateFullMethodName(
                  "io.axoniq.axonserver.grpc.admin.ContextAdminService", "SubscribeContextUpdates"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.protobuf.Empty.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  io.axoniq.axonserver.grpc.admin.ContextUpdate.getDefaultInstance()))
                  .setSchemaDescriptor(new ContextAdminServiceMethodDescriptorSupplier("SubscribeContextUpdates"))
                  .build();
          }
        }
     }
     return getSubscribeContextUpdatesMethod;
  }

  /**
   * Creates a new async stub that supports all call types for the service
   */
  public static ContextAdminServiceStub newStub(io.grpc.Channel channel) {
    return new ContextAdminServiceStub(channel);
  }

  /**
   * Creates a new blocking-style stub that supports unary and streaming output calls on the service
   */
  public static ContextAdminServiceBlockingStub newBlockingStub(
      io.grpc.Channel channel) {
    return new ContextAdminServiceBlockingStub(channel);
  }

  /**
   * Creates a new ListenableFuture-style stub that supports unary calls on the service
   */
  public static ContextAdminServiceFutureStub newFutureStub(
      io.grpc.Channel channel) {
    return new ContextAdminServiceFutureStub(channel);
  }

  /**
   * <pre>
   ************************* ContextAdminService *****************************
   * </pre>
   */
  public static abstract class ContextAdminServiceImplBase implements io.grpc.BindableService {

    /**
     */
    public void createContext(io.axoniq.axonserver.grpc.admin.CreateContextRequest request,
        io.grpc.stub.StreamObserver<com.google.protobuf.Empty> responseObserver) {
      asyncUnimplementedUnaryCall(getCreateContextMethod(), responseObserver);
    }

    /**
     */
    public void updateContextProperties(io.axoniq.axonserver.grpc.admin.UpdateContextPropertiesRequest request,
        io.grpc.stub.StreamObserver<com.google.protobuf.Empty> responseObserver) {
      asyncUnimplementedUnaryCall(getUpdateContextPropertiesMethod(), responseObserver);
    }

    /**
     */
    public void deleteContext(io.axoniq.axonserver.grpc.admin.DeleteContextRequest request,
        io.grpc.stub.StreamObserver<com.google.protobuf.Empty> responseObserver) {
      asyncUnimplementedUnaryCall(getDeleteContextMethod(), responseObserver);
    }

    /**
     */
    public void getContext(io.axoniq.axonserver.grpc.admin.GetContextRequest request,
        io.grpc.stub.StreamObserver<io.axoniq.axonserver.grpc.admin.ContextOverview> responseObserver) {
      asyncUnimplementedUnaryCall(getGetContextMethod(), responseObserver);
    }

    /**
     */
    public void getContexts(com.google.protobuf.Empty request,
        io.grpc.stub.StreamObserver<io.axoniq.axonserver.grpc.admin.ContextOverview> responseObserver) {
      asyncUnimplementedUnaryCall(getGetContextsMethod(), responseObserver);
    }

    /**
     */
    public void subscribeContextUpdates(com.google.protobuf.Empty request,
        io.grpc.stub.StreamObserver<io.axoniq.axonserver.grpc.admin.ContextUpdate> responseObserver) {
      asyncUnimplementedUnaryCall(getSubscribeContextUpdatesMethod(), responseObserver);
    }

    @java.lang.Override public final io.grpc.ServerServiceDefinition bindService() {
      return io.grpc.ServerServiceDefinition.builder(getServiceDescriptor())
          .addMethod(
            getCreateContextMethod(),
            asyncServerStreamingCall(
              new MethodHandlers<
                io.axoniq.axonserver.grpc.admin.CreateContextRequest,
                com.google.protobuf.Empty>(
                  this, METHODID_CREATE_CONTEXT)))
          .addMethod(
            getUpdateContextPropertiesMethod(),
            asyncServerStreamingCall(
              new MethodHandlers<
                io.axoniq.axonserver.grpc.admin.UpdateContextPropertiesRequest,
                com.google.protobuf.Empty>(
                  this, METHODID_UPDATE_CONTEXT_PROPERTIES)))
          .addMethod(
            getDeleteContextMethod(),
            asyncServerStreamingCall(
              new MethodHandlers<
                io.axoniq.axonserver.grpc.admin.DeleteContextRequest,
                com.google.protobuf.Empty>(
                  this, METHODID_DELETE_CONTEXT)))
          .addMethod(
            getGetContextMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                io.axoniq.axonserver.grpc.admin.GetContextRequest,
                io.axoniq.axonserver.grpc.admin.ContextOverview>(
                  this, METHODID_GET_CONTEXT)))
          .addMethod(
            getGetContextsMethod(),
            asyncServerStreamingCall(
              new MethodHandlers<
                com.google.protobuf.Empty,
                io.axoniq.axonserver.grpc.admin.ContextOverview>(
                  this, METHODID_GET_CONTEXTS)))
          .addMethod(
            getSubscribeContextUpdatesMethod(),
            asyncServerStreamingCall(
              new MethodHandlers<
                com.google.protobuf.Empty,
                io.axoniq.axonserver.grpc.admin.ContextUpdate>(
                  this, METHODID_SUBSCRIBE_CONTEXT_UPDATES)))
          .build();
    }
  }

  /**
   * <pre>
   ************************* ContextAdminService *****************************
   * </pre>
   */
  public static final class ContextAdminServiceStub extends io.grpc.stub.AbstractStub<ContextAdminServiceStub> {
    private ContextAdminServiceStub(io.grpc.Channel channel) {
      super(channel);
    }

    private ContextAdminServiceStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected ContextAdminServiceStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new ContextAdminServiceStub(channel, callOptions);
    }

    /**
     */
    public void createContext(io.axoniq.axonserver.grpc.admin.CreateContextRequest request,
        io.grpc.stub.StreamObserver<com.google.protobuf.Empty> responseObserver) {
      asyncServerStreamingCall(
          getChannel().newCall(getCreateContextMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void updateContextProperties(io.axoniq.axonserver.grpc.admin.UpdateContextPropertiesRequest request,
        io.grpc.stub.StreamObserver<com.google.protobuf.Empty> responseObserver) {
      asyncServerStreamingCall(
          getChannel().newCall(getUpdateContextPropertiesMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void deleteContext(io.axoniq.axonserver.grpc.admin.DeleteContextRequest request,
        io.grpc.stub.StreamObserver<com.google.protobuf.Empty> responseObserver) {
      asyncServerStreamingCall(
          getChannel().newCall(getDeleteContextMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void getContext(io.axoniq.axonserver.grpc.admin.GetContextRequest request,
        io.grpc.stub.StreamObserver<io.axoniq.axonserver.grpc.admin.ContextOverview> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getGetContextMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void getContexts(com.google.protobuf.Empty request,
        io.grpc.stub.StreamObserver<io.axoniq.axonserver.grpc.admin.ContextOverview> responseObserver) {
      asyncServerStreamingCall(
          getChannel().newCall(getGetContextsMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void subscribeContextUpdates(com.google.protobuf.Empty request,
        io.grpc.stub.StreamObserver<io.axoniq.axonserver.grpc.admin.ContextUpdate> responseObserver) {
      asyncServerStreamingCall(
          getChannel().newCall(getSubscribeContextUpdatesMethod(), getCallOptions()), request, responseObserver);
    }
  }

  /**
   * <pre>
   ************************* ContextAdminService *****************************
   * </pre>
   */
  public static final class ContextAdminServiceBlockingStub extends io.grpc.stub.AbstractStub<ContextAdminServiceBlockingStub> {
    private ContextAdminServiceBlockingStub(io.grpc.Channel channel) {
      super(channel);
    }

    private ContextAdminServiceBlockingStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected ContextAdminServiceBlockingStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new ContextAdminServiceBlockingStub(channel, callOptions);
    }

    /**
     */
    public java.util.Iterator<com.google.protobuf.Empty> createContext(
        io.axoniq.axonserver.grpc.admin.CreateContextRequest request) {
      return blockingServerStreamingCall(
          getChannel(), getCreateContextMethod(), getCallOptions(), request);
    }

    /**
     */
    public java.util.Iterator<com.google.protobuf.Empty> updateContextProperties(
        io.axoniq.axonserver.grpc.admin.UpdateContextPropertiesRequest request) {
      return blockingServerStreamingCall(
          getChannel(), getUpdateContextPropertiesMethod(), getCallOptions(), request);
    }

    /**
     */
    public java.util.Iterator<com.google.protobuf.Empty> deleteContext(
        io.axoniq.axonserver.grpc.admin.DeleteContextRequest request) {
      return blockingServerStreamingCall(
          getChannel(), getDeleteContextMethod(), getCallOptions(), request);
    }

    /**
     */
    public io.axoniq.axonserver.grpc.admin.ContextOverview getContext(io.axoniq.axonserver.grpc.admin.GetContextRequest request) {
      return blockingUnaryCall(
          getChannel(), getGetContextMethod(), getCallOptions(), request);
    }

    /**
     */
    public java.util.Iterator<io.axoniq.axonserver.grpc.admin.ContextOverview> getContexts(
        com.google.protobuf.Empty request) {
      return blockingServerStreamingCall(
          getChannel(), getGetContextsMethod(), getCallOptions(), request);
    }

    /**
     */
    public java.util.Iterator<io.axoniq.axonserver.grpc.admin.ContextUpdate> subscribeContextUpdates(
        com.google.protobuf.Empty request) {
      return blockingServerStreamingCall(
          getChannel(), getSubscribeContextUpdatesMethod(), getCallOptions(), request);
    }
  }

  /**
   * <pre>
   ************************* ContextAdminService *****************************
   * </pre>
   */
  public static final class ContextAdminServiceFutureStub extends io.grpc.stub.AbstractStub<ContextAdminServiceFutureStub> {
    private ContextAdminServiceFutureStub(io.grpc.Channel channel) {
      super(channel);
    }

    private ContextAdminServiceFutureStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected ContextAdminServiceFutureStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new ContextAdminServiceFutureStub(channel, callOptions);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<io.axoniq.axonserver.grpc.admin.ContextOverview> getContext(
        io.axoniq.axonserver.grpc.admin.GetContextRequest request) {
      return futureUnaryCall(
          getChannel().newCall(getGetContextMethod(), getCallOptions()), request);
    }
  }

  private static final int METHODID_CREATE_CONTEXT = 0;
  private static final int METHODID_UPDATE_CONTEXT_PROPERTIES = 1;
  private static final int METHODID_DELETE_CONTEXT = 2;
  private static final int METHODID_GET_CONTEXT = 3;
  private static final int METHODID_GET_CONTEXTS = 4;
  private static final int METHODID_SUBSCRIBE_CONTEXT_UPDATES = 5;

  private static final class MethodHandlers<Req, Resp> implements
      io.grpc.stub.ServerCalls.UnaryMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ServerStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ClientStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.BidiStreamingMethod<Req, Resp> {
    private final ContextAdminServiceImplBase serviceImpl;
    private final int methodId;

    MethodHandlers(ContextAdminServiceImplBase serviceImpl, int methodId) {
      this.serviceImpl = serviceImpl;
      this.methodId = methodId;
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public void invoke(Req request, io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_CREATE_CONTEXT:
          serviceImpl.createContext((io.axoniq.axonserver.grpc.admin.CreateContextRequest) request,
              (io.grpc.stub.StreamObserver<com.google.protobuf.Empty>) responseObserver);
          break;
        case METHODID_UPDATE_CONTEXT_PROPERTIES:
          serviceImpl.updateContextProperties((io.axoniq.axonserver.grpc.admin.UpdateContextPropertiesRequest) request,
              (io.grpc.stub.StreamObserver<com.google.protobuf.Empty>) responseObserver);
          break;
        case METHODID_DELETE_CONTEXT:
          serviceImpl.deleteContext((io.axoniq.axonserver.grpc.admin.DeleteContextRequest) request,
              (io.grpc.stub.StreamObserver<com.google.protobuf.Empty>) responseObserver);
          break;
        case METHODID_GET_CONTEXT:
          serviceImpl.getContext((io.axoniq.axonserver.grpc.admin.GetContextRequest) request,
              (io.grpc.stub.StreamObserver<io.axoniq.axonserver.grpc.admin.ContextOverview>) responseObserver);
          break;
        case METHODID_GET_CONTEXTS:
          serviceImpl.getContexts((com.google.protobuf.Empty) request,
              (io.grpc.stub.StreamObserver<io.axoniq.axonserver.grpc.admin.ContextOverview>) responseObserver);
          break;
        case METHODID_SUBSCRIBE_CONTEXT_UPDATES:
          serviceImpl.subscribeContextUpdates((com.google.protobuf.Empty) request,
              (io.grpc.stub.StreamObserver<io.axoniq.axonserver.grpc.admin.ContextUpdate>) responseObserver);
          break;
        default:
          throw new AssertionError();
      }
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public io.grpc.stub.StreamObserver<Req> invoke(
        io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        default:
          throw new AssertionError();
      }
    }
  }

  private static abstract class ContextAdminServiceBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoFileDescriptorSupplier, io.grpc.protobuf.ProtoServiceDescriptorSupplier {
    ContextAdminServiceBaseDescriptorSupplier() {}

    @java.lang.Override
    public com.google.protobuf.Descriptors.FileDescriptor getFileDescriptor() {
      return io.axoniq.axonserver.grpc.admin.Admin.getDescriptor();
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.ServiceDescriptor getServiceDescriptor() {
      return getFileDescriptor().findServiceByName("ContextAdminService");
    }
  }

  private static final class ContextAdminServiceFileDescriptorSupplier
      extends ContextAdminServiceBaseDescriptorSupplier {
    ContextAdminServiceFileDescriptorSupplier() {}
  }

  private static final class ContextAdminServiceMethodDescriptorSupplier
      extends ContextAdminServiceBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoMethodDescriptorSupplier {
    private final String methodName;

    ContextAdminServiceMethodDescriptorSupplier(String methodName) {
      this.methodName = methodName;
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.MethodDescriptor getMethodDescriptor() {
      return getServiceDescriptor().findMethodByName(methodName);
    }
  }

  private static volatile io.grpc.ServiceDescriptor serviceDescriptor;

  public static io.grpc.ServiceDescriptor getServiceDescriptor() {
    io.grpc.ServiceDescriptor result = serviceDescriptor;
    if (result == null) {
      synchronized (ContextAdminServiceGrpc.class) {
        result = serviceDescriptor;
        if (result == null) {
          serviceDescriptor = result = io.grpc.ServiceDescriptor.newBuilder(SERVICE_NAME)
              .setSchemaDescriptor(new ContextAdminServiceFileDescriptorSupplier())
              .addMethod(getCreateContextMethod())
              .addMethod(getUpdateContextPropertiesMethod())
              .addMethod(getDeleteContextMethod())
              .addMethod(getGetContextMethod())
              .addMethod(getGetContextsMethod())
              .addMethod(getSubscribeContextUpdatesMethod())
              .build();
        }
      }
    }
    return result;
  }
}

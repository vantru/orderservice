package io.axoniq.axonserver.grpc.streams;

import static io.grpc.MethodDescriptor.generateFullMethodName;
import static io.grpc.stub.ClientCalls.asyncBidiStreamingCall;
import static io.grpc.stub.ClientCalls.asyncClientStreamingCall;
import static io.grpc.stub.ClientCalls.asyncServerStreamingCall;
import static io.grpc.stub.ClientCalls.asyncUnaryCall;
import static io.grpc.stub.ClientCalls.blockingServerStreamingCall;
import static io.grpc.stub.ClientCalls.blockingUnaryCall;
import static io.grpc.stub.ClientCalls.futureUnaryCall;
import static io.grpc.stub.ServerCalls.asyncBidiStreamingCall;
import static io.grpc.stub.ServerCalls.asyncClientStreamingCall;
import static io.grpc.stub.ServerCalls.asyncServerStreamingCall;
import static io.grpc.stub.ServerCalls.asyncUnaryCall;
import static io.grpc.stub.ServerCalls.asyncUnimplementedStreamingCall;
import static io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall;

/**
 * <pre>
 * Service providing operations for persistent event streams, event streams where Axon Server keeps
 *track of the progress. All operations require a header (AxonIQ-Context) to be passed with each request to define
 *the context.
 * </pre>
 */
@javax.annotation.Generated(
    value = "by gRPC proto compiler (version 1.19.0)",
    comments = "Source: persistent-streams.proto")
public final class PersistentStreamServiceGrpc {

  private PersistentStreamServiceGrpc() {}

  public static final String SERVICE_NAME = "io.axoniq.axonserver.grpc.streams.PersistentStreamService";

  // Static method descriptors that strictly reflect the proto.
  private static volatile io.grpc.MethodDescriptor<io.axoniq.axonserver.grpc.streams.CreateStreamRequest,
      io.axoniq.axonserver.grpc.streams.CreateStreamResponse> getCreateStreamMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "CreateStream",
      requestType = io.axoniq.axonserver.grpc.streams.CreateStreamRequest.class,
      responseType = io.axoniq.axonserver.grpc.streams.CreateStreamResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<io.axoniq.axonserver.grpc.streams.CreateStreamRequest,
      io.axoniq.axonserver.grpc.streams.CreateStreamResponse> getCreateStreamMethod() {
    io.grpc.MethodDescriptor<io.axoniq.axonserver.grpc.streams.CreateStreamRequest, io.axoniq.axonserver.grpc.streams.CreateStreamResponse> getCreateStreamMethod;
    if ((getCreateStreamMethod = PersistentStreamServiceGrpc.getCreateStreamMethod) == null) {
      synchronized (PersistentStreamServiceGrpc.class) {
        if ((getCreateStreamMethod = PersistentStreamServiceGrpc.getCreateStreamMethod) == null) {
          PersistentStreamServiceGrpc.getCreateStreamMethod = getCreateStreamMethod = 
              io.grpc.MethodDescriptor.<io.axoniq.axonserver.grpc.streams.CreateStreamRequest, io.axoniq.axonserver.grpc.streams.CreateStreamResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "io.axoniq.axonserver.grpc.streams.PersistentStreamService", "CreateStream"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  io.axoniq.axonserver.grpc.streams.CreateStreamRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  io.axoniq.axonserver.grpc.streams.CreateStreamResponse.getDefaultInstance()))
                  .setSchemaDescriptor(new PersistentStreamServiceMethodDescriptorSupplier("CreateStream"))
                  .build();
          }
        }
     }
     return getCreateStreamMethod;
  }

  private static volatile io.grpc.MethodDescriptor<io.axoniq.axonserver.grpc.streams.StreamRequest,
      io.axoniq.axonserver.grpc.streams.StreamSignal> getOpenStreamMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "OpenStream",
      requestType = io.axoniq.axonserver.grpc.streams.StreamRequest.class,
      responseType = io.axoniq.axonserver.grpc.streams.StreamSignal.class,
      methodType = io.grpc.MethodDescriptor.MethodType.BIDI_STREAMING)
  public static io.grpc.MethodDescriptor<io.axoniq.axonserver.grpc.streams.StreamRequest,
      io.axoniq.axonserver.grpc.streams.StreamSignal> getOpenStreamMethod() {
    io.grpc.MethodDescriptor<io.axoniq.axonserver.grpc.streams.StreamRequest, io.axoniq.axonserver.grpc.streams.StreamSignal> getOpenStreamMethod;
    if ((getOpenStreamMethod = PersistentStreamServiceGrpc.getOpenStreamMethod) == null) {
      synchronized (PersistentStreamServiceGrpc.class) {
        if ((getOpenStreamMethod = PersistentStreamServiceGrpc.getOpenStreamMethod) == null) {
          PersistentStreamServiceGrpc.getOpenStreamMethod = getOpenStreamMethod = 
              io.grpc.MethodDescriptor.<io.axoniq.axonserver.grpc.streams.StreamRequest, io.axoniq.axonserver.grpc.streams.StreamSignal>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.BIDI_STREAMING)
              .setFullMethodName(generateFullMethodName(
                  "io.axoniq.axonserver.grpc.streams.PersistentStreamService", "OpenStream"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  io.axoniq.axonserver.grpc.streams.StreamRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  io.axoniq.axonserver.grpc.streams.StreamSignal.getDefaultInstance()))
                  .setSchemaDescriptor(new PersistentStreamServiceMethodDescriptorSupplier("OpenStream"))
                  .build();
          }
        }
     }
     return getOpenStreamMethod;
  }

  private static volatile io.grpc.MethodDescriptor<io.axoniq.axonserver.grpc.streams.DeleteStreamRequest,
      com.google.protobuf.Empty> getDeleteStreamMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "DeleteStream",
      requestType = io.axoniq.axonserver.grpc.streams.DeleteStreamRequest.class,
      responseType = com.google.protobuf.Empty.class,
      methodType = io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
  public static io.grpc.MethodDescriptor<io.axoniq.axonserver.grpc.streams.DeleteStreamRequest,
      com.google.protobuf.Empty> getDeleteStreamMethod() {
    io.grpc.MethodDescriptor<io.axoniq.axonserver.grpc.streams.DeleteStreamRequest, com.google.protobuf.Empty> getDeleteStreamMethod;
    if ((getDeleteStreamMethod = PersistentStreamServiceGrpc.getDeleteStreamMethod) == null) {
      synchronized (PersistentStreamServiceGrpc.class) {
        if ((getDeleteStreamMethod = PersistentStreamServiceGrpc.getDeleteStreamMethod) == null) {
          PersistentStreamServiceGrpc.getDeleteStreamMethod = getDeleteStreamMethod = 
              io.grpc.MethodDescriptor.<io.axoniq.axonserver.grpc.streams.DeleteStreamRequest, com.google.protobuf.Empty>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
              .setFullMethodName(generateFullMethodName(
                  "io.axoniq.axonserver.grpc.streams.PersistentStreamService", "DeleteStream"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  io.axoniq.axonserver.grpc.streams.DeleteStreamRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.protobuf.Empty.getDefaultInstance()))
                  .setSchemaDescriptor(new PersistentStreamServiceMethodDescriptorSupplier("DeleteStream"))
                  .build();
          }
        }
     }
     return getDeleteStreamMethod;
  }

  private static volatile io.grpc.MethodDescriptor<io.axoniq.axonserver.grpc.streams.UpdateStreamRequest,
      com.google.protobuf.Empty> getUpdateStreamMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "UpdateStream",
      requestType = io.axoniq.axonserver.grpc.streams.UpdateStreamRequest.class,
      responseType = com.google.protobuf.Empty.class,
      methodType = io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
  public static io.grpc.MethodDescriptor<io.axoniq.axonserver.grpc.streams.UpdateStreamRequest,
      com.google.protobuf.Empty> getUpdateStreamMethod() {
    io.grpc.MethodDescriptor<io.axoniq.axonserver.grpc.streams.UpdateStreamRequest, com.google.protobuf.Empty> getUpdateStreamMethod;
    if ((getUpdateStreamMethod = PersistentStreamServiceGrpc.getUpdateStreamMethod) == null) {
      synchronized (PersistentStreamServiceGrpc.class) {
        if ((getUpdateStreamMethod = PersistentStreamServiceGrpc.getUpdateStreamMethod) == null) {
          PersistentStreamServiceGrpc.getUpdateStreamMethod = getUpdateStreamMethod = 
              io.grpc.MethodDescriptor.<io.axoniq.axonserver.grpc.streams.UpdateStreamRequest, com.google.protobuf.Empty>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
              .setFullMethodName(generateFullMethodName(
                  "io.axoniq.axonserver.grpc.streams.PersistentStreamService", "UpdateStream"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  io.axoniq.axonserver.grpc.streams.UpdateStreamRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.protobuf.Empty.getDefaultInstance()))
                  .setSchemaDescriptor(new PersistentStreamServiceMethodDescriptorSupplier("UpdateStream"))
                  .build();
          }
        }
     }
     return getUpdateStreamMethod;
  }

  private static volatile io.grpc.MethodDescriptor<io.axoniq.axonserver.grpc.streams.ListStreamsRequest,
      io.axoniq.axonserver.grpc.streams.StreamStatus> getListStreamsMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "ListStreams",
      requestType = io.axoniq.axonserver.grpc.streams.ListStreamsRequest.class,
      responseType = io.axoniq.axonserver.grpc.streams.StreamStatus.class,
      methodType = io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
  public static io.grpc.MethodDescriptor<io.axoniq.axonserver.grpc.streams.ListStreamsRequest,
      io.axoniq.axonserver.grpc.streams.StreamStatus> getListStreamsMethod() {
    io.grpc.MethodDescriptor<io.axoniq.axonserver.grpc.streams.ListStreamsRequest, io.axoniq.axonserver.grpc.streams.StreamStatus> getListStreamsMethod;
    if ((getListStreamsMethod = PersistentStreamServiceGrpc.getListStreamsMethod) == null) {
      synchronized (PersistentStreamServiceGrpc.class) {
        if ((getListStreamsMethod = PersistentStreamServiceGrpc.getListStreamsMethod) == null) {
          PersistentStreamServiceGrpc.getListStreamsMethod = getListStreamsMethod = 
              io.grpc.MethodDescriptor.<io.axoniq.axonserver.grpc.streams.ListStreamsRequest, io.axoniq.axonserver.grpc.streams.StreamStatus>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
              .setFullMethodName(generateFullMethodName(
                  "io.axoniq.axonserver.grpc.streams.PersistentStreamService", "ListStreams"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  io.axoniq.axonserver.grpc.streams.ListStreamsRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  io.axoniq.axonserver.grpc.streams.StreamStatus.getDefaultInstance()))
                  .setSchemaDescriptor(new PersistentStreamServiceMethodDescriptorSupplier("ListStreams"))
                  .build();
          }
        }
     }
     return getListStreamsMethod;
  }

  private static volatile io.grpc.MethodDescriptor<io.axoniq.axonserver.grpc.streams.ResetStreamRequest,
      com.google.protobuf.Empty> getResetStreamMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "ResetStream",
      requestType = io.axoniq.axonserver.grpc.streams.ResetStreamRequest.class,
      responseType = com.google.protobuf.Empty.class,
      methodType = io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
  public static io.grpc.MethodDescriptor<io.axoniq.axonserver.grpc.streams.ResetStreamRequest,
      com.google.protobuf.Empty> getResetStreamMethod() {
    io.grpc.MethodDescriptor<io.axoniq.axonserver.grpc.streams.ResetStreamRequest, com.google.protobuf.Empty> getResetStreamMethod;
    if ((getResetStreamMethod = PersistentStreamServiceGrpc.getResetStreamMethod) == null) {
      synchronized (PersistentStreamServiceGrpc.class) {
        if ((getResetStreamMethod = PersistentStreamServiceGrpc.getResetStreamMethod) == null) {
          PersistentStreamServiceGrpc.getResetStreamMethod = getResetStreamMethod = 
              io.grpc.MethodDescriptor.<io.axoniq.axonserver.grpc.streams.ResetStreamRequest, com.google.protobuf.Empty>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
              .setFullMethodName(generateFullMethodName(
                  "io.axoniq.axonserver.grpc.streams.PersistentStreamService", "ResetStream"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  io.axoniq.axonserver.grpc.streams.ResetStreamRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.protobuf.Empty.getDefaultInstance()))
                  .setSchemaDescriptor(new PersistentStreamServiceMethodDescriptorSupplier("ResetStream"))
                  .build();
          }
        }
     }
     return getResetStreamMethod;
  }

  /**
   * Creates a new async stub that supports all call types for the service
   */
  public static PersistentStreamServiceStub newStub(io.grpc.Channel channel) {
    return new PersistentStreamServiceStub(channel);
  }

  /**
   * Creates a new blocking-style stub that supports unary and streaming output calls on the service
   */
  public static PersistentStreamServiceBlockingStub newBlockingStub(
      io.grpc.Channel channel) {
    return new PersistentStreamServiceBlockingStub(channel);
  }

  /**
   * Creates a new ListenableFuture-style stub that supports unary calls on the service
   */
  public static PersistentStreamServiceFutureStub newFutureStub(
      io.grpc.Channel channel) {
    return new PersistentStreamServiceFutureStub(channel);
  }

  /**
   * <pre>
   * Service providing operations for persistent event streams, event streams where Axon Server keeps
   *track of the progress. All operations require a header (AxonIQ-Context) to be passed with each request to define
   *the context.
   * </pre>
   */
  public static abstract class PersistentStreamServiceImplBase implements io.grpc.BindableService {

    /**
     * <pre>
     * Creates a persistent stream if it does not exist. 
     * </pre>
     */
    public void createStream(io.axoniq.axonserver.grpc.streams.CreateStreamRequest request,
        io.grpc.stub.StreamObserver<io.axoniq.axonserver.grpc.streams.CreateStreamResponse> responseObserver) {
      asyncUnimplementedUnaryCall(getCreateStreamMethod(), responseObserver);
    }

    /**
     * <pre>
     * Open a persistent event stream connection from a client. Creates the stream if it does not exist. 
     * </pre>
     */
    public io.grpc.stub.StreamObserver<io.axoniq.axonserver.grpc.streams.StreamRequest> openStream(
        io.grpc.stub.StreamObserver<io.axoniq.axonserver.grpc.streams.StreamSignal> responseObserver) {
      return asyncUnimplementedStreamingCall(getOpenStreamMethod(), responseObserver);
    }

    /**
     * <pre>
     * Deletes a persistent event stream. All existing connections to the stream are closed. 
     * </pre>
     */
    public void deleteStream(io.axoniq.axonserver.grpc.streams.DeleteStreamRequest request,
        io.grpc.stub.StreamObserver<com.google.protobuf.Empty> responseObserver) {
      asyncUnimplementedUnaryCall(getDeleteStreamMethod(), responseObserver);
    }

    /**
     * <pre>
     * Change properties of a persistent event stream. 
     * </pre>
     */
    public void updateStream(io.axoniq.axonserver.grpc.streams.UpdateStreamRequest request,
        io.grpc.stub.StreamObserver<com.google.protobuf.Empty> responseObserver) {
      asyncUnimplementedUnaryCall(getUpdateStreamMethod(), responseObserver);
    }

    /**
     * <pre>
     * Returns a list of all persistent event streams defined (for the context). For each event stream it returns
     *the progress per segment.  
     * </pre>
     */
    public void listStreams(io.axoniq.axonserver.grpc.streams.ListStreamsRequest request,
        io.grpc.stub.StreamObserver<io.axoniq.axonserver.grpc.streams.StreamStatus> responseObserver) {
      asyncUnimplementedUnaryCall(getListStreamsMethod(), responseObserver);
    }

    /**
     * <pre>
     * Resets the position of a persistent stream. 
     * </pre>
     */
    public void resetStream(io.axoniq.axonserver.grpc.streams.ResetStreamRequest request,
        io.grpc.stub.StreamObserver<com.google.protobuf.Empty> responseObserver) {
      asyncUnimplementedUnaryCall(getResetStreamMethod(), responseObserver);
    }

    @java.lang.Override public final io.grpc.ServerServiceDefinition bindService() {
      return io.grpc.ServerServiceDefinition.builder(getServiceDescriptor())
          .addMethod(
            getCreateStreamMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                io.axoniq.axonserver.grpc.streams.CreateStreamRequest,
                io.axoniq.axonserver.grpc.streams.CreateStreamResponse>(
                  this, METHODID_CREATE_STREAM)))
          .addMethod(
            getOpenStreamMethod(),
            asyncBidiStreamingCall(
              new MethodHandlers<
                io.axoniq.axonserver.grpc.streams.StreamRequest,
                io.axoniq.axonserver.grpc.streams.StreamSignal>(
                  this, METHODID_OPEN_STREAM)))
          .addMethod(
            getDeleteStreamMethod(),
            asyncServerStreamingCall(
              new MethodHandlers<
                io.axoniq.axonserver.grpc.streams.DeleteStreamRequest,
                com.google.protobuf.Empty>(
                  this, METHODID_DELETE_STREAM)))
          .addMethod(
            getUpdateStreamMethod(),
            asyncServerStreamingCall(
              new MethodHandlers<
                io.axoniq.axonserver.grpc.streams.UpdateStreamRequest,
                com.google.protobuf.Empty>(
                  this, METHODID_UPDATE_STREAM)))
          .addMethod(
            getListStreamsMethod(),
            asyncServerStreamingCall(
              new MethodHandlers<
                io.axoniq.axonserver.grpc.streams.ListStreamsRequest,
                io.axoniq.axonserver.grpc.streams.StreamStatus>(
                  this, METHODID_LIST_STREAMS)))
          .addMethod(
            getResetStreamMethod(),
            asyncServerStreamingCall(
              new MethodHandlers<
                io.axoniq.axonserver.grpc.streams.ResetStreamRequest,
                com.google.protobuf.Empty>(
                  this, METHODID_RESET_STREAM)))
          .build();
    }
  }

  /**
   * <pre>
   * Service providing operations for persistent event streams, event streams where Axon Server keeps
   *track of the progress. All operations require a header (AxonIQ-Context) to be passed with each request to define
   *the context.
   * </pre>
   */
  public static final class PersistentStreamServiceStub extends io.grpc.stub.AbstractStub<PersistentStreamServiceStub> {
    private PersistentStreamServiceStub(io.grpc.Channel channel) {
      super(channel);
    }

    private PersistentStreamServiceStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected PersistentStreamServiceStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new PersistentStreamServiceStub(channel, callOptions);
    }

    /**
     * <pre>
     * Creates a persistent stream if it does not exist. 
     * </pre>
     */
    public void createStream(io.axoniq.axonserver.grpc.streams.CreateStreamRequest request,
        io.grpc.stub.StreamObserver<io.axoniq.axonserver.grpc.streams.CreateStreamResponse> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getCreateStreamMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Open a persistent event stream connection from a client. Creates the stream if it does not exist. 
     * </pre>
     */
    public io.grpc.stub.StreamObserver<io.axoniq.axonserver.grpc.streams.StreamRequest> openStream(
        io.grpc.stub.StreamObserver<io.axoniq.axonserver.grpc.streams.StreamSignal> responseObserver) {
      return asyncBidiStreamingCall(
          getChannel().newCall(getOpenStreamMethod(), getCallOptions()), responseObserver);
    }

    /**
     * <pre>
     * Deletes a persistent event stream. All existing connections to the stream are closed. 
     * </pre>
     */
    public void deleteStream(io.axoniq.axonserver.grpc.streams.DeleteStreamRequest request,
        io.grpc.stub.StreamObserver<com.google.protobuf.Empty> responseObserver) {
      asyncServerStreamingCall(
          getChannel().newCall(getDeleteStreamMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Change properties of a persistent event stream. 
     * </pre>
     */
    public void updateStream(io.axoniq.axonserver.grpc.streams.UpdateStreamRequest request,
        io.grpc.stub.StreamObserver<com.google.protobuf.Empty> responseObserver) {
      asyncServerStreamingCall(
          getChannel().newCall(getUpdateStreamMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Returns a list of all persistent event streams defined (for the context). For each event stream it returns
     *the progress per segment.  
     * </pre>
     */
    public void listStreams(io.axoniq.axonserver.grpc.streams.ListStreamsRequest request,
        io.grpc.stub.StreamObserver<io.axoniq.axonserver.grpc.streams.StreamStatus> responseObserver) {
      asyncServerStreamingCall(
          getChannel().newCall(getListStreamsMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Resets the position of a persistent stream. 
     * </pre>
     */
    public void resetStream(io.axoniq.axonserver.grpc.streams.ResetStreamRequest request,
        io.grpc.stub.StreamObserver<com.google.protobuf.Empty> responseObserver) {
      asyncServerStreamingCall(
          getChannel().newCall(getResetStreamMethod(), getCallOptions()), request, responseObserver);
    }
  }

  /**
   * <pre>
   * Service providing operations for persistent event streams, event streams where Axon Server keeps
   *track of the progress. All operations require a header (AxonIQ-Context) to be passed with each request to define
   *the context.
   * </pre>
   */
  public static final class PersistentStreamServiceBlockingStub extends io.grpc.stub.AbstractStub<PersistentStreamServiceBlockingStub> {
    private PersistentStreamServiceBlockingStub(io.grpc.Channel channel) {
      super(channel);
    }

    private PersistentStreamServiceBlockingStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected PersistentStreamServiceBlockingStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new PersistentStreamServiceBlockingStub(channel, callOptions);
    }

    /**
     * <pre>
     * Creates a persistent stream if it does not exist. 
     * </pre>
     */
    public io.axoniq.axonserver.grpc.streams.CreateStreamResponse createStream(io.axoniq.axonserver.grpc.streams.CreateStreamRequest request) {
      return blockingUnaryCall(
          getChannel(), getCreateStreamMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Deletes a persistent event stream. All existing connections to the stream are closed. 
     * </pre>
     */
    public java.util.Iterator<com.google.protobuf.Empty> deleteStream(
        io.axoniq.axonserver.grpc.streams.DeleteStreamRequest request) {
      return blockingServerStreamingCall(
          getChannel(), getDeleteStreamMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Change properties of a persistent event stream. 
     * </pre>
     */
    public java.util.Iterator<com.google.protobuf.Empty> updateStream(
        io.axoniq.axonserver.grpc.streams.UpdateStreamRequest request) {
      return blockingServerStreamingCall(
          getChannel(), getUpdateStreamMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Returns a list of all persistent event streams defined (for the context). For each event stream it returns
     *the progress per segment.  
     * </pre>
     */
    public java.util.Iterator<io.axoniq.axonserver.grpc.streams.StreamStatus> listStreams(
        io.axoniq.axonserver.grpc.streams.ListStreamsRequest request) {
      return blockingServerStreamingCall(
          getChannel(), getListStreamsMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Resets the position of a persistent stream. 
     * </pre>
     */
    public java.util.Iterator<com.google.protobuf.Empty> resetStream(
        io.axoniq.axonserver.grpc.streams.ResetStreamRequest request) {
      return blockingServerStreamingCall(
          getChannel(), getResetStreamMethod(), getCallOptions(), request);
    }
  }

  /**
   * <pre>
   * Service providing operations for persistent event streams, event streams where Axon Server keeps
   *track of the progress. All operations require a header (AxonIQ-Context) to be passed with each request to define
   *the context.
   * </pre>
   */
  public static final class PersistentStreamServiceFutureStub extends io.grpc.stub.AbstractStub<PersistentStreamServiceFutureStub> {
    private PersistentStreamServiceFutureStub(io.grpc.Channel channel) {
      super(channel);
    }

    private PersistentStreamServiceFutureStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected PersistentStreamServiceFutureStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new PersistentStreamServiceFutureStub(channel, callOptions);
    }

    /**
     * <pre>
     * Creates a persistent stream if it does not exist. 
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<io.axoniq.axonserver.grpc.streams.CreateStreamResponse> createStream(
        io.axoniq.axonserver.grpc.streams.CreateStreamRequest request) {
      return futureUnaryCall(
          getChannel().newCall(getCreateStreamMethod(), getCallOptions()), request);
    }
  }

  private static final int METHODID_CREATE_STREAM = 0;
  private static final int METHODID_DELETE_STREAM = 1;
  private static final int METHODID_UPDATE_STREAM = 2;
  private static final int METHODID_LIST_STREAMS = 3;
  private static final int METHODID_RESET_STREAM = 4;
  private static final int METHODID_OPEN_STREAM = 5;

  private static final class MethodHandlers<Req, Resp> implements
      io.grpc.stub.ServerCalls.UnaryMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ServerStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ClientStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.BidiStreamingMethod<Req, Resp> {
    private final PersistentStreamServiceImplBase serviceImpl;
    private final int methodId;

    MethodHandlers(PersistentStreamServiceImplBase serviceImpl, int methodId) {
      this.serviceImpl = serviceImpl;
      this.methodId = methodId;
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public void invoke(Req request, io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_CREATE_STREAM:
          serviceImpl.createStream((io.axoniq.axonserver.grpc.streams.CreateStreamRequest) request,
              (io.grpc.stub.StreamObserver<io.axoniq.axonserver.grpc.streams.CreateStreamResponse>) responseObserver);
          break;
        case METHODID_DELETE_STREAM:
          serviceImpl.deleteStream((io.axoniq.axonserver.grpc.streams.DeleteStreamRequest) request,
              (io.grpc.stub.StreamObserver<com.google.protobuf.Empty>) responseObserver);
          break;
        case METHODID_UPDATE_STREAM:
          serviceImpl.updateStream((io.axoniq.axonserver.grpc.streams.UpdateStreamRequest) request,
              (io.grpc.stub.StreamObserver<com.google.protobuf.Empty>) responseObserver);
          break;
        case METHODID_LIST_STREAMS:
          serviceImpl.listStreams((io.axoniq.axonserver.grpc.streams.ListStreamsRequest) request,
              (io.grpc.stub.StreamObserver<io.axoniq.axonserver.grpc.streams.StreamStatus>) responseObserver);
          break;
        case METHODID_RESET_STREAM:
          serviceImpl.resetStream((io.axoniq.axonserver.grpc.streams.ResetStreamRequest) request,
              (io.grpc.stub.StreamObserver<com.google.protobuf.Empty>) responseObserver);
          break;
        default:
          throw new AssertionError();
      }
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public io.grpc.stub.StreamObserver<Req> invoke(
        io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_OPEN_STREAM:
          return (io.grpc.stub.StreamObserver<Req>) serviceImpl.openStream(
              (io.grpc.stub.StreamObserver<io.axoniq.axonserver.grpc.streams.StreamSignal>) responseObserver);
        default:
          throw new AssertionError();
      }
    }
  }

  private static abstract class PersistentStreamServiceBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoFileDescriptorSupplier, io.grpc.protobuf.ProtoServiceDescriptorSupplier {
    PersistentStreamServiceBaseDescriptorSupplier() {}

    @java.lang.Override
    public com.google.protobuf.Descriptors.FileDescriptor getFileDescriptor() {
      return io.axoniq.axonserver.grpc.streams.PersistentStreams.getDescriptor();
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.ServiceDescriptor getServiceDescriptor() {
      return getFileDescriptor().findServiceByName("PersistentStreamService");
    }
  }

  private static final class PersistentStreamServiceFileDescriptorSupplier
      extends PersistentStreamServiceBaseDescriptorSupplier {
    PersistentStreamServiceFileDescriptorSupplier() {}
  }

  private static final class PersistentStreamServiceMethodDescriptorSupplier
      extends PersistentStreamServiceBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoMethodDescriptorSupplier {
    private final String methodName;

    PersistentStreamServiceMethodDescriptorSupplier(String methodName) {
      this.methodName = methodName;
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.MethodDescriptor getMethodDescriptor() {
      return getServiceDescriptor().findMethodByName(methodName);
    }
  }

  private static volatile io.grpc.ServiceDescriptor serviceDescriptor;

  public static io.grpc.ServiceDescriptor getServiceDescriptor() {
    io.grpc.ServiceDescriptor result = serviceDescriptor;
    if (result == null) {
      synchronized (PersistentStreamServiceGrpc.class) {
        result = serviceDescriptor;
        if (result == null) {
          serviceDescriptor = result = io.grpc.ServiceDescriptor.newBuilder(SERVICE_NAME)
              .setSchemaDescriptor(new PersistentStreamServiceFileDescriptorSupplier())
              .addMethod(getCreateStreamMethod())
              .addMethod(getOpenStreamMethod())
              .addMethod(getDeleteStreamMethod())
              .addMethod(getUpdateStreamMethod())
              .addMethod(getListStreamsMethod())
              .addMethod(getResetStreamMethod())
              .build();
        }
      }
    }
    return result;
  }
}

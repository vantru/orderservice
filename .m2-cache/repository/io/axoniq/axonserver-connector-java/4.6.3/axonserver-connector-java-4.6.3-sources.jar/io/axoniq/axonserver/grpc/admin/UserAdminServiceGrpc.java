package io.axoniq.axonserver.grpc.admin;

import static io.grpc.MethodDescriptor.generateFullMethodName;
import static io.grpc.stub.ClientCalls.asyncBidiStreamingCall;
import static io.grpc.stub.ClientCalls.asyncClientStreamingCall;
import static io.grpc.stub.ClientCalls.asyncServerStreamingCall;
import static io.grpc.stub.ClientCalls.asyncUnaryCall;
import static io.grpc.stub.ClientCalls.blockingServerStreamingCall;
import static io.grpc.stub.ClientCalls.blockingUnaryCall;
import static io.grpc.stub.ClientCalls.futureUnaryCall;
import static io.grpc.stub.ServerCalls.asyncBidiStreamingCall;
import static io.grpc.stub.ServerCalls.asyncClientStreamingCall;
import static io.grpc.stub.ServerCalls.asyncServerStreamingCall;
import static io.grpc.stub.ServerCalls.asyncUnaryCall;
import static io.grpc.stub.ServerCalls.asyncUnimplementedStreamingCall;
import static io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall;

/**
 * <pre>
 ************************* UserAdminService *****************************
 * </pre>
 */
@javax.annotation.Generated(
    value = "by gRPC proto compiler (version 1.19.0)",
    comments = "Source: admin.proto")
public final class UserAdminServiceGrpc {

  private UserAdminServiceGrpc() {}

  public static final String SERVICE_NAME = "io.axoniq.axonserver.grpc.admin.UserAdminService";

  // Static method descriptors that strictly reflect the proto.
  private static volatile io.grpc.MethodDescriptor<io.axoniq.axonserver.grpc.admin.CreateOrUpdateUserRequest,
      com.google.protobuf.Empty> getCreateOrUpdateUserMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "CreateOrUpdateUser",
      requestType = io.axoniq.axonserver.grpc.admin.CreateOrUpdateUserRequest.class,
      responseType = com.google.protobuf.Empty.class,
      methodType = io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
  public static io.grpc.MethodDescriptor<io.axoniq.axonserver.grpc.admin.CreateOrUpdateUserRequest,
      com.google.protobuf.Empty> getCreateOrUpdateUserMethod() {
    io.grpc.MethodDescriptor<io.axoniq.axonserver.grpc.admin.CreateOrUpdateUserRequest, com.google.protobuf.Empty> getCreateOrUpdateUserMethod;
    if ((getCreateOrUpdateUserMethod = UserAdminServiceGrpc.getCreateOrUpdateUserMethod) == null) {
      synchronized (UserAdminServiceGrpc.class) {
        if ((getCreateOrUpdateUserMethod = UserAdminServiceGrpc.getCreateOrUpdateUserMethod) == null) {
          UserAdminServiceGrpc.getCreateOrUpdateUserMethod = getCreateOrUpdateUserMethod = 
              io.grpc.MethodDescriptor.<io.axoniq.axonserver.grpc.admin.CreateOrUpdateUserRequest, com.google.protobuf.Empty>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
              .setFullMethodName(generateFullMethodName(
                  "io.axoniq.axonserver.grpc.admin.UserAdminService", "CreateOrUpdateUser"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  io.axoniq.axonserver.grpc.admin.CreateOrUpdateUserRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.protobuf.Empty.getDefaultInstance()))
                  .setSchemaDescriptor(new UserAdminServiceMethodDescriptorSupplier("CreateOrUpdateUser"))
                  .build();
          }
        }
     }
     return getCreateOrUpdateUserMethod;
  }

  private static volatile io.grpc.MethodDescriptor<io.axoniq.axonserver.grpc.admin.DeleteUserRequest,
      com.google.protobuf.Empty> getDeleteUserMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "DeleteUser",
      requestType = io.axoniq.axonserver.grpc.admin.DeleteUserRequest.class,
      responseType = com.google.protobuf.Empty.class,
      methodType = io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
  public static io.grpc.MethodDescriptor<io.axoniq.axonserver.grpc.admin.DeleteUserRequest,
      com.google.protobuf.Empty> getDeleteUserMethod() {
    io.grpc.MethodDescriptor<io.axoniq.axonserver.grpc.admin.DeleteUserRequest, com.google.protobuf.Empty> getDeleteUserMethod;
    if ((getDeleteUserMethod = UserAdminServiceGrpc.getDeleteUserMethod) == null) {
      synchronized (UserAdminServiceGrpc.class) {
        if ((getDeleteUserMethod = UserAdminServiceGrpc.getDeleteUserMethod) == null) {
          UserAdminServiceGrpc.getDeleteUserMethod = getDeleteUserMethod = 
              io.grpc.MethodDescriptor.<io.axoniq.axonserver.grpc.admin.DeleteUserRequest, com.google.protobuf.Empty>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
              .setFullMethodName(generateFullMethodName(
                  "io.axoniq.axonserver.grpc.admin.UserAdminService", "DeleteUser"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  io.axoniq.axonserver.grpc.admin.DeleteUserRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.protobuf.Empty.getDefaultInstance()))
                  .setSchemaDescriptor(new UserAdminServiceMethodDescriptorSupplier("DeleteUser"))
                  .build();
          }
        }
     }
     return getDeleteUserMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.google.protobuf.Empty,
      io.axoniq.axonserver.grpc.admin.UserOverview> getGetUsersMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetUsers",
      requestType = com.google.protobuf.Empty.class,
      responseType = io.axoniq.axonserver.grpc.admin.UserOverview.class,
      methodType = io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
  public static io.grpc.MethodDescriptor<com.google.protobuf.Empty,
      io.axoniq.axonserver.grpc.admin.UserOverview> getGetUsersMethod() {
    io.grpc.MethodDescriptor<com.google.protobuf.Empty, io.axoniq.axonserver.grpc.admin.UserOverview> getGetUsersMethod;
    if ((getGetUsersMethod = UserAdminServiceGrpc.getGetUsersMethod) == null) {
      synchronized (UserAdminServiceGrpc.class) {
        if ((getGetUsersMethod = UserAdminServiceGrpc.getGetUsersMethod) == null) {
          UserAdminServiceGrpc.getGetUsersMethod = getGetUsersMethod = 
              io.grpc.MethodDescriptor.<com.google.protobuf.Empty, io.axoniq.axonserver.grpc.admin.UserOverview>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
              .setFullMethodName(generateFullMethodName(
                  "io.axoniq.axonserver.grpc.admin.UserAdminService", "GetUsers"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.protobuf.Empty.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  io.axoniq.axonserver.grpc.admin.UserOverview.getDefaultInstance()))
                  .setSchemaDescriptor(new UserAdminServiceMethodDescriptorSupplier("GetUsers"))
                  .build();
          }
        }
     }
     return getGetUsersMethod;
  }

  /**
   * Creates a new async stub that supports all call types for the service
   */
  public static UserAdminServiceStub newStub(io.grpc.Channel channel) {
    return new UserAdminServiceStub(channel);
  }

  /**
   * Creates a new blocking-style stub that supports unary and streaming output calls on the service
   */
  public static UserAdminServiceBlockingStub newBlockingStub(
      io.grpc.Channel channel) {
    return new UserAdminServiceBlockingStub(channel);
  }

  /**
   * Creates a new ListenableFuture-style stub that supports unary calls on the service
   */
  public static UserAdminServiceFutureStub newFutureStub(
      io.grpc.Channel channel) {
    return new UserAdminServiceFutureStub(channel);
  }

  /**
   * <pre>
   ************************* UserAdminService *****************************
   * </pre>
   */
  public static abstract class UserAdminServiceImplBase implements io.grpc.BindableService {

    /**
     */
    public void createOrUpdateUser(io.axoniq.axonserver.grpc.admin.CreateOrUpdateUserRequest request,
        io.grpc.stub.StreamObserver<com.google.protobuf.Empty> responseObserver) {
      asyncUnimplementedUnaryCall(getCreateOrUpdateUserMethod(), responseObserver);
    }

    /**
     */
    public void deleteUser(io.axoniq.axonserver.grpc.admin.DeleteUserRequest request,
        io.grpc.stub.StreamObserver<com.google.protobuf.Empty> responseObserver) {
      asyncUnimplementedUnaryCall(getDeleteUserMethod(), responseObserver);
    }

    /**
     */
    public void getUsers(com.google.protobuf.Empty request,
        io.grpc.stub.StreamObserver<io.axoniq.axonserver.grpc.admin.UserOverview> responseObserver) {
      asyncUnimplementedUnaryCall(getGetUsersMethod(), responseObserver);
    }

    @java.lang.Override public final io.grpc.ServerServiceDefinition bindService() {
      return io.grpc.ServerServiceDefinition.builder(getServiceDescriptor())
          .addMethod(
            getCreateOrUpdateUserMethod(),
            asyncServerStreamingCall(
              new MethodHandlers<
                io.axoniq.axonserver.grpc.admin.CreateOrUpdateUserRequest,
                com.google.protobuf.Empty>(
                  this, METHODID_CREATE_OR_UPDATE_USER)))
          .addMethod(
            getDeleteUserMethod(),
            asyncServerStreamingCall(
              new MethodHandlers<
                io.axoniq.axonserver.grpc.admin.DeleteUserRequest,
                com.google.protobuf.Empty>(
                  this, METHODID_DELETE_USER)))
          .addMethod(
            getGetUsersMethod(),
            asyncServerStreamingCall(
              new MethodHandlers<
                com.google.protobuf.Empty,
                io.axoniq.axonserver.grpc.admin.UserOverview>(
                  this, METHODID_GET_USERS)))
          .build();
    }
  }

  /**
   * <pre>
   ************************* UserAdminService *****************************
   * </pre>
   */
  public static final class UserAdminServiceStub extends io.grpc.stub.AbstractStub<UserAdminServiceStub> {
    private UserAdminServiceStub(io.grpc.Channel channel) {
      super(channel);
    }

    private UserAdminServiceStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected UserAdminServiceStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new UserAdminServiceStub(channel, callOptions);
    }

    /**
     */
    public void createOrUpdateUser(io.axoniq.axonserver.grpc.admin.CreateOrUpdateUserRequest request,
        io.grpc.stub.StreamObserver<com.google.protobuf.Empty> responseObserver) {
      asyncServerStreamingCall(
          getChannel().newCall(getCreateOrUpdateUserMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void deleteUser(io.axoniq.axonserver.grpc.admin.DeleteUserRequest request,
        io.grpc.stub.StreamObserver<com.google.protobuf.Empty> responseObserver) {
      asyncServerStreamingCall(
          getChannel().newCall(getDeleteUserMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void getUsers(com.google.protobuf.Empty request,
        io.grpc.stub.StreamObserver<io.axoniq.axonserver.grpc.admin.UserOverview> responseObserver) {
      asyncServerStreamingCall(
          getChannel().newCall(getGetUsersMethod(), getCallOptions()), request, responseObserver);
    }
  }

  /**
   * <pre>
   ************************* UserAdminService *****************************
   * </pre>
   */
  public static final class UserAdminServiceBlockingStub extends io.grpc.stub.AbstractStub<UserAdminServiceBlockingStub> {
    private UserAdminServiceBlockingStub(io.grpc.Channel channel) {
      super(channel);
    }

    private UserAdminServiceBlockingStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected UserAdminServiceBlockingStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new UserAdminServiceBlockingStub(channel, callOptions);
    }

    /**
     */
    public java.util.Iterator<com.google.protobuf.Empty> createOrUpdateUser(
        io.axoniq.axonserver.grpc.admin.CreateOrUpdateUserRequest request) {
      return blockingServerStreamingCall(
          getChannel(), getCreateOrUpdateUserMethod(), getCallOptions(), request);
    }

    /**
     */
    public java.util.Iterator<com.google.protobuf.Empty> deleteUser(
        io.axoniq.axonserver.grpc.admin.DeleteUserRequest request) {
      return blockingServerStreamingCall(
          getChannel(), getDeleteUserMethod(), getCallOptions(), request);
    }

    /**
     */
    public java.util.Iterator<io.axoniq.axonserver.grpc.admin.UserOverview> getUsers(
        com.google.protobuf.Empty request) {
      return blockingServerStreamingCall(
          getChannel(), getGetUsersMethod(), getCallOptions(), request);
    }
  }

  /**
   * <pre>
   ************************* UserAdminService *****************************
   * </pre>
   */
  public static final class UserAdminServiceFutureStub extends io.grpc.stub.AbstractStub<UserAdminServiceFutureStub> {
    private UserAdminServiceFutureStub(io.grpc.Channel channel) {
      super(channel);
    }

    private UserAdminServiceFutureStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected UserAdminServiceFutureStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new UserAdminServiceFutureStub(channel, callOptions);
    }
  }

  private static final int METHODID_CREATE_OR_UPDATE_USER = 0;
  private static final int METHODID_DELETE_USER = 1;
  private static final int METHODID_GET_USERS = 2;

  private static final class MethodHandlers<Req, Resp> implements
      io.grpc.stub.ServerCalls.UnaryMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ServerStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ClientStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.BidiStreamingMethod<Req, Resp> {
    private final UserAdminServiceImplBase serviceImpl;
    private final int methodId;

    MethodHandlers(UserAdminServiceImplBase serviceImpl, int methodId) {
      this.serviceImpl = serviceImpl;
      this.methodId = methodId;
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public void invoke(Req request, io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_CREATE_OR_UPDATE_USER:
          serviceImpl.createOrUpdateUser((io.axoniq.axonserver.grpc.admin.CreateOrUpdateUserRequest) request,
              (io.grpc.stub.StreamObserver<com.google.protobuf.Empty>) responseObserver);
          break;
        case METHODID_DELETE_USER:
          serviceImpl.deleteUser((io.axoniq.axonserver.grpc.admin.DeleteUserRequest) request,
              (io.grpc.stub.StreamObserver<com.google.protobuf.Empty>) responseObserver);
          break;
        case METHODID_GET_USERS:
          serviceImpl.getUsers((com.google.protobuf.Empty) request,
              (io.grpc.stub.StreamObserver<io.axoniq.axonserver.grpc.admin.UserOverview>) responseObserver);
          break;
        default:
          throw new AssertionError();
      }
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public io.grpc.stub.StreamObserver<Req> invoke(
        io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        default:
          throw new AssertionError();
      }
    }
  }

  private static abstract class UserAdminServiceBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoFileDescriptorSupplier, io.grpc.protobuf.ProtoServiceDescriptorSupplier {
    UserAdminServiceBaseDescriptorSupplier() {}

    @java.lang.Override
    public com.google.protobuf.Descriptors.FileDescriptor getFileDescriptor() {
      return io.axoniq.axonserver.grpc.admin.Admin.getDescriptor();
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.ServiceDescriptor getServiceDescriptor() {
      return getFileDescriptor().findServiceByName("UserAdminService");
    }
  }

  private static final class UserAdminServiceFileDescriptorSupplier
      extends UserAdminServiceBaseDescriptorSupplier {
    UserAdminServiceFileDescriptorSupplier() {}
  }

  private static final class UserAdminServiceMethodDescriptorSupplier
      extends UserAdminServiceBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoMethodDescriptorSupplier {
    private final String methodName;

    UserAdminServiceMethodDescriptorSupplier(String methodName) {
      this.methodName = methodName;
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.MethodDescriptor getMethodDescriptor() {
      return getServiceDescriptor().findMethodByName(methodName);
    }
  }

  private static volatile io.grpc.ServiceDescriptor serviceDescriptor;

  public static io.grpc.ServiceDescriptor getServiceDescriptor() {
    io.grpc.ServiceDescriptor result = serviceDescriptor;
    if (result == null) {
      synchronized (UserAdminServiceGrpc.class) {
        result = serviceDescriptor;
        if (result == null) {
          serviceDescriptor = result = io.grpc.ServiceDescriptor.newBuilder(SERVICE_NAME)
              .setSchemaDescriptor(new UserAdminServiceFileDescriptorSupplier())
              .addMethod(getCreateOrUpdateUserMethod())
              .addMethod(getDeleteUserMethod())
              .addMethod(getGetUsersMethod())
              .build();
        }
      }
    }
    return result;
  }
}

package io.axoniq.axonserver.grpc.admin;

import static io.grpc.MethodDescriptor.generateFullMethodName;
import static io.grpc.stub.ClientCalls.asyncBidiStreamingCall;
import static io.grpc.stub.ClientCalls.asyncClientStreamingCall;
import static io.grpc.stub.ClientCalls.asyncServerStreamingCall;
import static io.grpc.stub.ClientCalls.asyncUnaryCall;
import static io.grpc.stub.ClientCalls.blockingServerStreamingCall;
import static io.grpc.stub.ClientCalls.blockingUnaryCall;
import static io.grpc.stub.ClientCalls.futureUnaryCall;
import static io.grpc.stub.ServerCalls.asyncBidiStreamingCall;
import static io.grpc.stub.ServerCalls.asyncClientStreamingCall;
import static io.grpc.stub.ServerCalls.asyncServerStreamingCall;
import static io.grpc.stub.ServerCalls.asyncUnaryCall;
import static io.grpc.stub.ServerCalls.asyncUnimplementedStreamingCall;
import static io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall;

/**
 */
@javax.annotation.Generated(
    value = "by gRPC proto compiler (version 1.19.0)",
    comments = "Source: admin.proto")
public final class ReplicationGroupAdminServiceGrpc {

  private ReplicationGroupAdminServiceGrpc() {}

  public static final String SERVICE_NAME = "io.axoniq.axonserver.grpc.admin.ReplicationGroupAdminService";

  // Static method descriptors that strictly reflect the proto.
  private static volatile io.grpc.MethodDescriptor<com.google.protobuf.Empty,
      io.axoniq.axonserver.grpc.admin.NodeOverview> getGetNodesMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetNodes",
      requestType = com.google.protobuf.Empty.class,
      responseType = io.axoniq.axonserver.grpc.admin.NodeOverview.class,
      methodType = io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
  public static io.grpc.MethodDescriptor<com.google.protobuf.Empty,
      io.axoniq.axonserver.grpc.admin.NodeOverview> getGetNodesMethod() {
    io.grpc.MethodDescriptor<com.google.protobuf.Empty, io.axoniq.axonserver.grpc.admin.NodeOverview> getGetNodesMethod;
    if ((getGetNodesMethod = ReplicationGroupAdminServiceGrpc.getGetNodesMethod) == null) {
      synchronized (ReplicationGroupAdminServiceGrpc.class) {
        if ((getGetNodesMethod = ReplicationGroupAdminServiceGrpc.getGetNodesMethod) == null) {
          ReplicationGroupAdminServiceGrpc.getGetNodesMethod = getGetNodesMethod = 
              io.grpc.MethodDescriptor.<com.google.protobuf.Empty, io.axoniq.axonserver.grpc.admin.NodeOverview>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
              .setFullMethodName(generateFullMethodName(
                  "io.axoniq.axonserver.grpc.admin.ReplicationGroupAdminService", "GetNodes"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.protobuf.Empty.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  io.axoniq.axonserver.grpc.admin.NodeOverview.getDefaultInstance()))
                  .setSchemaDescriptor(new ReplicationGroupAdminServiceMethodDescriptorSupplier("GetNodes"))
                  .build();
          }
        }
     }
     return getGetNodesMethod;
  }

  private static volatile io.grpc.MethodDescriptor<io.axoniq.axonserver.grpc.admin.CreateReplicationGroupRequest,
      com.google.protobuf.Empty> getCreateReplicationGroupMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "CreateReplicationGroup",
      requestType = io.axoniq.axonserver.grpc.admin.CreateReplicationGroupRequest.class,
      responseType = com.google.protobuf.Empty.class,
      methodType = io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
  public static io.grpc.MethodDescriptor<io.axoniq.axonserver.grpc.admin.CreateReplicationGroupRequest,
      com.google.protobuf.Empty> getCreateReplicationGroupMethod() {
    io.grpc.MethodDescriptor<io.axoniq.axonserver.grpc.admin.CreateReplicationGroupRequest, com.google.protobuf.Empty> getCreateReplicationGroupMethod;
    if ((getCreateReplicationGroupMethod = ReplicationGroupAdminServiceGrpc.getCreateReplicationGroupMethod) == null) {
      synchronized (ReplicationGroupAdminServiceGrpc.class) {
        if ((getCreateReplicationGroupMethod = ReplicationGroupAdminServiceGrpc.getCreateReplicationGroupMethod) == null) {
          ReplicationGroupAdminServiceGrpc.getCreateReplicationGroupMethod = getCreateReplicationGroupMethod = 
              io.grpc.MethodDescriptor.<io.axoniq.axonserver.grpc.admin.CreateReplicationGroupRequest, com.google.protobuf.Empty>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
              .setFullMethodName(generateFullMethodName(
                  "io.axoniq.axonserver.grpc.admin.ReplicationGroupAdminService", "CreateReplicationGroup"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  io.axoniq.axonserver.grpc.admin.CreateReplicationGroupRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.protobuf.Empty.getDefaultInstance()))
                  .setSchemaDescriptor(new ReplicationGroupAdminServiceMethodDescriptorSupplier("CreateReplicationGroup"))
                  .build();
          }
        }
     }
     return getCreateReplicationGroupMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.google.protobuf.Empty,
      io.axoniq.axonserver.grpc.admin.ReplicationGroupOverview> getGetReplicationGroupsMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetReplicationGroups",
      requestType = com.google.protobuf.Empty.class,
      responseType = io.axoniq.axonserver.grpc.admin.ReplicationGroupOverview.class,
      methodType = io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
  public static io.grpc.MethodDescriptor<com.google.protobuf.Empty,
      io.axoniq.axonserver.grpc.admin.ReplicationGroupOverview> getGetReplicationGroupsMethod() {
    io.grpc.MethodDescriptor<com.google.protobuf.Empty, io.axoniq.axonserver.grpc.admin.ReplicationGroupOverview> getGetReplicationGroupsMethod;
    if ((getGetReplicationGroupsMethod = ReplicationGroupAdminServiceGrpc.getGetReplicationGroupsMethod) == null) {
      synchronized (ReplicationGroupAdminServiceGrpc.class) {
        if ((getGetReplicationGroupsMethod = ReplicationGroupAdminServiceGrpc.getGetReplicationGroupsMethod) == null) {
          ReplicationGroupAdminServiceGrpc.getGetReplicationGroupsMethod = getGetReplicationGroupsMethod = 
              io.grpc.MethodDescriptor.<com.google.protobuf.Empty, io.axoniq.axonserver.grpc.admin.ReplicationGroupOverview>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
              .setFullMethodName(generateFullMethodName(
                  "io.axoniq.axonserver.grpc.admin.ReplicationGroupAdminService", "GetReplicationGroups"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.protobuf.Empty.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  io.axoniq.axonserver.grpc.admin.ReplicationGroupOverview.getDefaultInstance()))
                  .setSchemaDescriptor(new ReplicationGroupAdminServiceMethodDescriptorSupplier("GetReplicationGroups"))
                  .build();
          }
        }
     }
     return getGetReplicationGroupsMethod;
  }

  private static volatile io.grpc.MethodDescriptor<io.axoniq.axonserver.grpc.admin.GetReplicationGroupRequest,
      io.axoniq.axonserver.grpc.admin.ReplicationGroupOverview> getGetReplicationGroupMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetReplicationGroup",
      requestType = io.axoniq.axonserver.grpc.admin.GetReplicationGroupRequest.class,
      responseType = io.axoniq.axonserver.grpc.admin.ReplicationGroupOverview.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<io.axoniq.axonserver.grpc.admin.GetReplicationGroupRequest,
      io.axoniq.axonserver.grpc.admin.ReplicationGroupOverview> getGetReplicationGroupMethod() {
    io.grpc.MethodDescriptor<io.axoniq.axonserver.grpc.admin.GetReplicationGroupRequest, io.axoniq.axonserver.grpc.admin.ReplicationGroupOverview> getGetReplicationGroupMethod;
    if ((getGetReplicationGroupMethod = ReplicationGroupAdminServiceGrpc.getGetReplicationGroupMethod) == null) {
      synchronized (ReplicationGroupAdminServiceGrpc.class) {
        if ((getGetReplicationGroupMethod = ReplicationGroupAdminServiceGrpc.getGetReplicationGroupMethod) == null) {
          ReplicationGroupAdminServiceGrpc.getGetReplicationGroupMethod = getGetReplicationGroupMethod = 
              io.grpc.MethodDescriptor.<io.axoniq.axonserver.grpc.admin.GetReplicationGroupRequest, io.axoniq.axonserver.grpc.admin.ReplicationGroupOverview>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(
                  "io.axoniq.axonserver.grpc.admin.ReplicationGroupAdminService", "GetReplicationGroup"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  io.axoniq.axonserver.grpc.admin.GetReplicationGroupRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  io.axoniq.axonserver.grpc.admin.ReplicationGroupOverview.getDefaultInstance()))
                  .setSchemaDescriptor(new ReplicationGroupAdminServiceMethodDescriptorSupplier("GetReplicationGroup"))
                  .build();
          }
        }
     }
     return getGetReplicationGroupMethod;
  }

  private static volatile io.grpc.MethodDescriptor<io.axoniq.axonserver.grpc.admin.DeleteReplicationGroupRequest,
      com.google.protobuf.Empty> getDeleteReplicationGroupMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "DeleteReplicationGroup",
      requestType = io.axoniq.axonserver.grpc.admin.DeleteReplicationGroupRequest.class,
      responseType = com.google.protobuf.Empty.class,
      methodType = io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
  public static io.grpc.MethodDescriptor<io.axoniq.axonserver.grpc.admin.DeleteReplicationGroupRequest,
      com.google.protobuf.Empty> getDeleteReplicationGroupMethod() {
    io.grpc.MethodDescriptor<io.axoniq.axonserver.grpc.admin.DeleteReplicationGroupRequest, com.google.protobuf.Empty> getDeleteReplicationGroupMethod;
    if ((getDeleteReplicationGroupMethod = ReplicationGroupAdminServiceGrpc.getDeleteReplicationGroupMethod) == null) {
      synchronized (ReplicationGroupAdminServiceGrpc.class) {
        if ((getDeleteReplicationGroupMethod = ReplicationGroupAdminServiceGrpc.getDeleteReplicationGroupMethod) == null) {
          ReplicationGroupAdminServiceGrpc.getDeleteReplicationGroupMethod = getDeleteReplicationGroupMethod = 
              io.grpc.MethodDescriptor.<io.axoniq.axonserver.grpc.admin.DeleteReplicationGroupRequest, com.google.protobuf.Empty>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
              .setFullMethodName(generateFullMethodName(
                  "io.axoniq.axonserver.grpc.admin.ReplicationGroupAdminService", "DeleteReplicationGroup"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  io.axoniq.axonserver.grpc.admin.DeleteReplicationGroupRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.protobuf.Empty.getDefaultInstance()))
                  .setSchemaDescriptor(new ReplicationGroupAdminServiceMethodDescriptorSupplier("DeleteReplicationGroup"))
                  .build();
          }
        }
     }
     return getDeleteReplicationGroupMethod;
  }

  private static volatile io.grpc.MethodDescriptor<io.axoniq.axonserver.grpc.admin.JoinReplicationGroup,
      com.google.protobuf.Empty> getAddNodeToReplicationGroupMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "AddNodeToReplicationGroup",
      requestType = io.axoniq.axonserver.grpc.admin.JoinReplicationGroup.class,
      responseType = com.google.protobuf.Empty.class,
      methodType = io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
  public static io.grpc.MethodDescriptor<io.axoniq.axonserver.grpc.admin.JoinReplicationGroup,
      com.google.protobuf.Empty> getAddNodeToReplicationGroupMethod() {
    io.grpc.MethodDescriptor<io.axoniq.axonserver.grpc.admin.JoinReplicationGroup, com.google.protobuf.Empty> getAddNodeToReplicationGroupMethod;
    if ((getAddNodeToReplicationGroupMethod = ReplicationGroupAdminServiceGrpc.getAddNodeToReplicationGroupMethod) == null) {
      synchronized (ReplicationGroupAdminServiceGrpc.class) {
        if ((getAddNodeToReplicationGroupMethod = ReplicationGroupAdminServiceGrpc.getAddNodeToReplicationGroupMethod) == null) {
          ReplicationGroupAdminServiceGrpc.getAddNodeToReplicationGroupMethod = getAddNodeToReplicationGroupMethod = 
              io.grpc.MethodDescriptor.<io.axoniq.axonserver.grpc.admin.JoinReplicationGroup, com.google.protobuf.Empty>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
              .setFullMethodName(generateFullMethodName(
                  "io.axoniq.axonserver.grpc.admin.ReplicationGroupAdminService", "AddNodeToReplicationGroup"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  io.axoniq.axonserver.grpc.admin.JoinReplicationGroup.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.protobuf.Empty.getDefaultInstance()))
                  .setSchemaDescriptor(new ReplicationGroupAdminServiceMethodDescriptorSupplier("AddNodeToReplicationGroup"))
                  .build();
          }
        }
     }
     return getAddNodeToReplicationGroupMethod;
  }

  private static volatile io.grpc.MethodDescriptor<io.axoniq.axonserver.grpc.admin.LeaveReplicationGroup,
      com.google.protobuf.Empty> getRemoveNodeFromReplicationGroupMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "RemoveNodeFromReplicationGroup",
      requestType = io.axoniq.axonserver.grpc.admin.LeaveReplicationGroup.class,
      responseType = com.google.protobuf.Empty.class,
      methodType = io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
  public static io.grpc.MethodDescriptor<io.axoniq.axonserver.grpc.admin.LeaveReplicationGroup,
      com.google.protobuf.Empty> getRemoveNodeFromReplicationGroupMethod() {
    io.grpc.MethodDescriptor<io.axoniq.axonserver.grpc.admin.LeaveReplicationGroup, com.google.protobuf.Empty> getRemoveNodeFromReplicationGroupMethod;
    if ((getRemoveNodeFromReplicationGroupMethod = ReplicationGroupAdminServiceGrpc.getRemoveNodeFromReplicationGroupMethod) == null) {
      synchronized (ReplicationGroupAdminServiceGrpc.class) {
        if ((getRemoveNodeFromReplicationGroupMethod = ReplicationGroupAdminServiceGrpc.getRemoveNodeFromReplicationGroupMethod) == null) {
          ReplicationGroupAdminServiceGrpc.getRemoveNodeFromReplicationGroupMethod = getRemoveNodeFromReplicationGroupMethod = 
              io.grpc.MethodDescriptor.<io.axoniq.axonserver.grpc.admin.LeaveReplicationGroup, com.google.protobuf.Empty>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
              .setFullMethodName(generateFullMethodName(
                  "io.axoniq.axonserver.grpc.admin.ReplicationGroupAdminService", "RemoveNodeFromReplicationGroup"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  io.axoniq.axonserver.grpc.admin.LeaveReplicationGroup.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.protobuf.Empty.getDefaultInstance()))
                  .setSchemaDescriptor(new ReplicationGroupAdminServiceMethodDescriptorSupplier("RemoveNodeFromReplicationGroup"))
                  .build();
          }
        }
     }
     return getRemoveNodeFromReplicationGroupMethod;
  }

  /**
   * Creates a new async stub that supports all call types for the service
   */
  public static ReplicationGroupAdminServiceStub newStub(io.grpc.Channel channel) {
    return new ReplicationGroupAdminServiceStub(channel);
  }

  /**
   * Creates a new blocking-style stub that supports unary and streaming output calls on the service
   */
  public static ReplicationGroupAdminServiceBlockingStub newBlockingStub(
      io.grpc.Channel channel) {
    return new ReplicationGroupAdminServiceBlockingStub(channel);
  }

  /**
   * Creates a new ListenableFuture-style stub that supports unary calls on the service
   */
  public static ReplicationGroupAdminServiceFutureStub newFutureStub(
      io.grpc.Channel channel) {
    return new ReplicationGroupAdminServiceFutureStub(channel);
  }

  /**
   */
  public static abstract class ReplicationGroupAdminServiceImplBase implements io.grpc.BindableService {

    /**
     */
    public void getNodes(com.google.protobuf.Empty request,
        io.grpc.stub.StreamObserver<io.axoniq.axonserver.grpc.admin.NodeOverview> responseObserver) {
      asyncUnimplementedUnaryCall(getGetNodesMethod(), responseObserver);
    }

    /**
     */
    public void createReplicationGroup(io.axoniq.axonserver.grpc.admin.CreateReplicationGroupRequest request,
        io.grpc.stub.StreamObserver<com.google.protobuf.Empty> responseObserver) {
      asyncUnimplementedUnaryCall(getCreateReplicationGroupMethod(), responseObserver);
    }

    /**
     */
    public void getReplicationGroups(com.google.protobuf.Empty request,
        io.grpc.stub.StreamObserver<io.axoniq.axonserver.grpc.admin.ReplicationGroupOverview> responseObserver) {
      asyncUnimplementedUnaryCall(getGetReplicationGroupsMethod(), responseObserver);
    }

    /**
     */
    public void getReplicationGroup(io.axoniq.axonserver.grpc.admin.GetReplicationGroupRequest request,
        io.grpc.stub.StreamObserver<io.axoniq.axonserver.grpc.admin.ReplicationGroupOverview> responseObserver) {
      asyncUnimplementedUnaryCall(getGetReplicationGroupMethod(), responseObserver);
    }

    /**
     */
    public void deleteReplicationGroup(io.axoniq.axonserver.grpc.admin.DeleteReplicationGroupRequest request,
        io.grpc.stub.StreamObserver<com.google.protobuf.Empty> responseObserver) {
      asyncUnimplementedUnaryCall(getDeleteReplicationGroupMethod(), responseObserver);
    }

    /**
     */
    public void addNodeToReplicationGroup(io.axoniq.axonserver.grpc.admin.JoinReplicationGroup request,
        io.grpc.stub.StreamObserver<com.google.protobuf.Empty> responseObserver) {
      asyncUnimplementedUnaryCall(getAddNodeToReplicationGroupMethod(), responseObserver);
    }

    /**
     */
    public void removeNodeFromReplicationGroup(io.axoniq.axonserver.grpc.admin.LeaveReplicationGroup request,
        io.grpc.stub.StreamObserver<com.google.protobuf.Empty> responseObserver) {
      asyncUnimplementedUnaryCall(getRemoveNodeFromReplicationGroupMethod(), responseObserver);
    }

    @java.lang.Override public final io.grpc.ServerServiceDefinition bindService() {
      return io.grpc.ServerServiceDefinition.builder(getServiceDescriptor())
          .addMethod(
            getGetNodesMethod(),
            asyncServerStreamingCall(
              new MethodHandlers<
                com.google.protobuf.Empty,
                io.axoniq.axonserver.grpc.admin.NodeOverview>(
                  this, METHODID_GET_NODES)))
          .addMethod(
            getCreateReplicationGroupMethod(),
            asyncServerStreamingCall(
              new MethodHandlers<
                io.axoniq.axonserver.grpc.admin.CreateReplicationGroupRequest,
                com.google.protobuf.Empty>(
                  this, METHODID_CREATE_REPLICATION_GROUP)))
          .addMethod(
            getGetReplicationGroupsMethod(),
            asyncServerStreamingCall(
              new MethodHandlers<
                com.google.protobuf.Empty,
                io.axoniq.axonserver.grpc.admin.ReplicationGroupOverview>(
                  this, METHODID_GET_REPLICATION_GROUPS)))
          .addMethod(
            getGetReplicationGroupMethod(),
            asyncUnaryCall(
              new MethodHandlers<
                io.axoniq.axonserver.grpc.admin.GetReplicationGroupRequest,
                io.axoniq.axonserver.grpc.admin.ReplicationGroupOverview>(
                  this, METHODID_GET_REPLICATION_GROUP)))
          .addMethod(
            getDeleteReplicationGroupMethod(),
            asyncServerStreamingCall(
              new MethodHandlers<
                io.axoniq.axonserver.grpc.admin.DeleteReplicationGroupRequest,
                com.google.protobuf.Empty>(
                  this, METHODID_DELETE_REPLICATION_GROUP)))
          .addMethod(
            getAddNodeToReplicationGroupMethod(),
            asyncServerStreamingCall(
              new MethodHandlers<
                io.axoniq.axonserver.grpc.admin.JoinReplicationGroup,
                com.google.protobuf.Empty>(
                  this, METHODID_ADD_NODE_TO_REPLICATION_GROUP)))
          .addMethod(
            getRemoveNodeFromReplicationGroupMethod(),
            asyncServerStreamingCall(
              new MethodHandlers<
                io.axoniq.axonserver.grpc.admin.LeaveReplicationGroup,
                com.google.protobuf.Empty>(
                  this, METHODID_REMOVE_NODE_FROM_REPLICATION_GROUP)))
          .build();
    }
  }

  /**
   */
  public static final class ReplicationGroupAdminServiceStub extends io.grpc.stub.AbstractStub<ReplicationGroupAdminServiceStub> {
    private ReplicationGroupAdminServiceStub(io.grpc.Channel channel) {
      super(channel);
    }

    private ReplicationGroupAdminServiceStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected ReplicationGroupAdminServiceStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new ReplicationGroupAdminServiceStub(channel, callOptions);
    }

    /**
     */
    public void getNodes(com.google.protobuf.Empty request,
        io.grpc.stub.StreamObserver<io.axoniq.axonserver.grpc.admin.NodeOverview> responseObserver) {
      asyncServerStreamingCall(
          getChannel().newCall(getGetNodesMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void createReplicationGroup(io.axoniq.axonserver.grpc.admin.CreateReplicationGroupRequest request,
        io.grpc.stub.StreamObserver<com.google.protobuf.Empty> responseObserver) {
      asyncServerStreamingCall(
          getChannel().newCall(getCreateReplicationGroupMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void getReplicationGroups(com.google.protobuf.Empty request,
        io.grpc.stub.StreamObserver<io.axoniq.axonserver.grpc.admin.ReplicationGroupOverview> responseObserver) {
      asyncServerStreamingCall(
          getChannel().newCall(getGetReplicationGroupsMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void getReplicationGroup(io.axoniq.axonserver.grpc.admin.GetReplicationGroupRequest request,
        io.grpc.stub.StreamObserver<io.axoniq.axonserver.grpc.admin.ReplicationGroupOverview> responseObserver) {
      asyncUnaryCall(
          getChannel().newCall(getGetReplicationGroupMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void deleteReplicationGroup(io.axoniq.axonserver.grpc.admin.DeleteReplicationGroupRequest request,
        io.grpc.stub.StreamObserver<com.google.protobuf.Empty> responseObserver) {
      asyncServerStreamingCall(
          getChannel().newCall(getDeleteReplicationGroupMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void addNodeToReplicationGroup(io.axoniq.axonserver.grpc.admin.JoinReplicationGroup request,
        io.grpc.stub.StreamObserver<com.google.protobuf.Empty> responseObserver) {
      asyncServerStreamingCall(
          getChannel().newCall(getAddNodeToReplicationGroupMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     */
    public void removeNodeFromReplicationGroup(io.axoniq.axonserver.grpc.admin.LeaveReplicationGroup request,
        io.grpc.stub.StreamObserver<com.google.protobuf.Empty> responseObserver) {
      asyncServerStreamingCall(
          getChannel().newCall(getRemoveNodeFromReplicationGroupMethod(), getCallOptions()), request, responseObserver);
    }
  }

  /**
   */
  public static final class ReplicationGroupAdminServiceBlockingStub extends io.grpc.stub.AbstractStub<ReplicationGroupAdminServiceBlockingStub> {
    private ReplicationGroupAdminServiceBlockingStub(io.grpc.Channel channel) {
      super(channel);
    }

    private ReplicationGroupAdminServiceBlockingStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected ReplicationGroupAdminServiceBlockingStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new ReplicationGroupAdminServiceBlockingStub(channel, callOptions);
    }

    /**
     */
    public java.util.Iterator<io.axoniq.axonserver.grpc.admin.NodeOverview> getNodes(
        com.google.protobuf.Empty request) {
      return blockingServerStreamingCall(
          getChannel(), getGetNodesMethod(), getCallOptions(), request);
    }

    /**
     */
    public java.util.Iterator<com.google.protobuf.Empty> createReplicationGroup(
        io.axoniq.axonserver.grpc.admin.CreateReplicationGroupRequest request) {
      return blockingServerStreamingCall(
          getChannel(), getCreateReplicationGroupMethod(), getCallOptions(), request);
    }

    /**
     */
    public java.util.Iterator<io.axoniq.axonserver.grpc.admin.ReplicationGroupOverview> getReplicationGroups(
        com.google.protobuf.Empty request) {
      return blockingServerStreamingCall(
          getChannel(), getGetReplicationGroupsMethod(), getCallOptions(), request);
    }

    /**
     */
    public io.axoniq.axonserver.grpc.admin.ReplicationGroupOverview getReplicationGroup(io.axoniq.axonserver.grpc.admin.GetReplicationGroupRequest request) {
      return blockingUnaryCall(
          getChannel(), getGetReplicationGroupMethod(), getCallOptions(), request);
    }

    /**
     */
    public java.util.Iterator<com.google.protobuf.Empty> deleteReplicationGroup(
        io.axoniq.axonserver.grpc.admin.DeleteReplicationGroupRequest request) {
      return blockingServerStreamingCall(
          getChannel(), getDeleteReplicationGroupMethod(), getCallOptions(), request);
    }

    /**
     */
    public java.util.Iterator<com.google.protobuf.Empty> addNodeToReplicationGroup(
        io.axoniq.axonserver.grpc.admin.JoinReplicationGroup request) {
      return blockingServerStreamingCall(
          getChannel(), getAddNodeToReplicationGroupMethod(), getCallOptions(), request);
    }

    /**
     */
    public java.util.Iterator<com.google.protobuf.Empty> removeNodeFromReplicationGroup(
        io.axoniq.axonserver.grpc.admin.LeaveReplicationGroup request) {
      return blockingServerStreamingCall(
          getChannel(), getRemoveNodeFromReplicationGroupMethod(), getCallOptions(), request);
    }
  }

  /**
   */
  public static final class ReplicationGroupAdminServiceFutureStub extends io.grpc.stub.AbstractStub<ReplicationGroupAdminServiceFutureStub> {
    private ReplicationGroupAdminServiceFutureStub(io.grpc.Channel channel) {
      super(channel);
    }

    private ReplicationGroupAdminServiceFutureStub(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected ReplicationGroupAdminServiceFutureStub build(io.grpc.Channel channel,
        io.grpc.CallOptions callOptions) {
      return new ReplicationGroupAdminServiceFutureStub(channel, callOptions);
    }

    /**
     */
    public com.google.common.util.concurrent.ListenableFuture<io.axoniq.axonserver.grpc.admin.ReplicationGroupOverview> getReplicationGroup(
        io.axoniq.axonserver.grpc.admin.GetReplicationGroupRequest request) {
      return futureUnaryCall(
          getChannel().newCall(getGetReplicationGroupMethod(), getCallOptions()), request);
    }
  }

  private static final int METHODID_GET_NODES = 0;
  private static final int METHODID_CREATE_REPLICATION_GROUP = 1;
  private static final int METHODID_GET_REPLICATION_GROUPS = 2;
  private static final int METHODID_GET_REPLICATION_GROUP = 3;
  private static final int METHODID_DELETE_REPLICATION_GROUP = 4;
  private static final int METHODID_ADD_NODE_TO_REPLICATION_GROUP = 5;
  private static final int METHODID_REMOVE_NODE_FROM_REPLICATION_GROUP = 6;

  private static final class MethodHandlers<Req, Resp> implements
      io.grpc.stub.ServerCalls.UnaryMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ServerStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ClientStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.BidiStreamingMethod<Req, Resp> {
    private final ReplicationGroupAdminServiceImplBase serviceImpl;
    private final int methodId;

    MethodHandlers(ReplicationGroupAdminServiceImplBase serviceImpl, int methodId) {
      this.serviceImpl = serviceImpl;
      this.methodId = methodId;
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public void invoke(Req request, io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_GET_NODES:
          serviceImpl.getNodes((com.google.protobuf.Empty) request,
              (io.grpc.stub.StreamObserver<io.axoniq.axonserver.grpc.admin.NodeOverview>) responseObserver);
          break;
        case METHODID_CREATE_REPLICATION_GROUP:
          serviceImpl.createReplicationGroup((io.axoniq.axonserver.grpc.admin.CreateReplicationGroupRequest) request,
              (io.grpc.stub.StreamObserver<com.google.protobuf.Empty>) responseObserver);
          break;
        case METHODID_GET_REPLICATION_GROUPS:
          serviceImpl.getReplicationGroups((com.google.protobuf.Empty) request,
              (io.grpc.stub.StreamObserver<io.axoniq.axonserver.grpc.admin.ReplicationGroupOverview>) responseObserver);
          break;
        case METHODID_GET_REPLICATION_GROUP:
          serviceImpl.getReplicationGroup((io.axoniq.axonserver.grpc.admin.GetReplicationGroupRequest) request,
              (io.grpc.stub.StreamObserver<io.axoniq.axonserver.grpc.admin.ReplicationGroupOverview>) responseObserver);
          break;
        case METHODID_DELETE_REPLICATION_GROUP:
          serviceImpl.deleteReplicationGroup((io.axoniq.axonserver.grpc.admin.DeleteReplicationGroupRequest) request,
              (io.grpc.stub.StreamObserver<com.google.protobuf.Empty>) responseObserver);
          break;
        case METHODID_ADD_NODE_TO_REPLICATION_GROUP:
          serviceImpl.addNodeToReplicationGroup((io.axoniq.axonserver.grpc.admin.JoinReplicationGroup) request,
              (io.grpc.stub.StreamObserver<com.google.protobuf.Empty>) responseObserver);
          break;
        case METHODID_REMOVE_NODE_FROM_REPLICATION_GROUP:
          serviceImpl.removeNodeFromReplicationGroup((io.axoniq.axonserver.grpc.admin.LeaveReplicationGroup) request,
              (io.grpc.stub.StreamObserver<com.google.protobuf.Empty>) responseObserver);
          break;
        default:
          throw new AssertionError();
      }
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public io.grpc.stub.StreamObserver<Req> invoke(
        io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        default:
          throw new AssertionError();
      }
    }
  }

  private static abstract class ReplicationGroupAdminServiceBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoFileDescriptorSupplier, io.grpc.protobuf.ProtoServiceDescriptorSupplier {
    ReplicationGroupAdminServiceBaseDescriptorSupplier() {}

    @java.lang.Override
    public com.google.protobuf.Descriptors.FileDescriptor getFileDescriptor() {
      return io.axoniq.axonserver.grpc.admin.Admin.getDescriptor();
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.ServiceDescriptor getServiceDescriptor() {
      return getFileDescriptor().findServiceByName("ReplicationGroupAdminService");
    }
  }

  private static final class ReplicationGroupAdminServiceFileDescriptorSupplier
      extends ReplicationGroupAdminServiceBaseDescriptorSupplier {
    ReplicationGroupAdminServiceFileDescriptorSupplier() {}
  }

  private static final class ReplicationGroupAdminServiceMethodDescriptorSupplier
      extends ReplicationGroupAdminServiceBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoMethodDescriptorSupplier {
    private final String methodName;

    ReplicationGroupAdminServiceMethodDescriptorSupplier(String methodName) {
      this.methodName = methodName;
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.MethodDescriptor getMethodDescriptor() {
      return getServiceDescriptor().findMethodByName(methodName);
    }
  }

  private static volatile io.grpc.ServiceDescriptor serviceDescriptor;

  public static io.grpc.ServiceDescriptor getServiceDescriptor() {
    io.grpc.ServiceDescriptor result = serviceDescriptor;
    if (result == null) {
      synchronized (ReplicationGroupAdminServiceGrpc.class) {
        result = serviceDescriptor;
        if (result == null) {
          serviceDescriptor = result = io.grpc.ServiceDescriptor.newBuilder(SERVICE_NAME)
              .setSchemaDescriptor(new ReplicationGroupAdminServiceFileDescriptorSupplier())
              .addMethod(getGetNodesMethod())
              .addMethod(getCreateReplicationGroupMethod())
              .addMethod(getGetReplicationGroupsMethod())
              .addMethod(getGetReplicationGroupMethod())
              .addMethod(getDeleteReplicationGroupMethod())
              .addMethod(getAddNodeToReplicationGroupMethod())
              .addMethod(getRemoveNodeFromReplicationGroupMethod())
              .build();
        }
      }
    }
    return result;
  }
}

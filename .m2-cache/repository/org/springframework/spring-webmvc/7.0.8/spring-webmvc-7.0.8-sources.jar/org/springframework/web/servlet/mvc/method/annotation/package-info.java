/**
 * MVC infrastructure for annotation-based handler method processing, building on the
 * {@code org.springframework.web.method.annotation} package. Entry points are
 * {@link org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerMapping}
 * and {@link org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerAdapter}.
 */
@NullMarked
package org.springframework.web.servlet.mvc.method.annotation;

import org.jspecify.annotations.NullMarked;
